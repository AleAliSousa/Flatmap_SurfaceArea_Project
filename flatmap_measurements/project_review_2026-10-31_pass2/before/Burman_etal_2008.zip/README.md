# Burman_etal_2008

REJECTED FOR ANALYSIS: all 24 existing ROIs are held pending retracing after failed anatomical spot checks. See the boundary audit linked from the gallery. A separate CJ58R printed-interior shape pilot is not a whole-field estimate. Marmoset: dorsal M1 components, M1-face component and core visual/sensory/auditory fields from Fig9A. Pixel areas only: Fig6 caption prints 1 μm, inconsistent with a whole-brain image; Fig9 bar length is not specified. No silent correction to 1 mm. Additional atlas labels are listed as not yet digitized, not falsely classified as impossible.

## Results

- [Source-versus-tracing gallery](review/gallery.html)
- [Measurements](data/measurements.csv)
- [Figure inventory](documentation/figure_inventory.csv)
- [Validation](documentation/validation.json)

Canonical editable geometry is in `figures/<map_id>/rois.json`. Every traced view has a calibrated or pixel-unit `source.tif`, editable ImageJ `RoiSet.zip`, masks and `tracing.png`. Source-only views intentionally contain no ROI.

All measurements remain provisional manual digitizations. Source review and native ImageJ read-back do not certify anatomical accuracy. No field sum was used to invent a whole-neocortex denominator. A view is not an animal.

Rebuild from this folder with `python scripts/measure_flatmaps.py --rebuild`, then `python scripts/measure_flatmaps.py --verify`. Batch tables/report can be regenerated with the batch report script.

<!-- atlas-guidance -->
## Atlases and tracing guides

For anatomical review, consult the [Nencki–Monash marmoset template](https://www.marmosetbrain.org/nencki_monash_template), which supplies a flatmap, midthickness surface and probabilistic cytoarchitectural labels. The [Marmoset Brain Connectivity Atlas reference page](https://www.marmosetbrain.org/reference) provides the Paxinos et al. (2012) stereotaxic atlas and Majka et al. (2016) registration methods. See the [project atlas and guide directory](../ReadMe.md#atlases-and-tracing-guides) for uses, limitations and the surface-registration guide.

These atlases are proposed anatomical references, not sources of the current contours or calibration. No atlas registration or predicted sulcal layer has been applied. Group-average atlas shapes must not replace the observed anatomy of CJ58R or CJ61.

The source captions govern the interpretation:

- **Fig. 6, including CJ61:** gray bands represent uncertainty in architectural borders; the dashed line is the authors' best estimate of the M1 outer boundary. LS identifies the lateral sulcus. The colored stimulation territories are not complete architectural fields. Caption: PDF page 9, printed page 868.
- **Fig. 9, CJ58R:** gray bands are architectural boundary regions; dashed gray lines are borders estimated from other animals. Solid lines include map boundaries and major cortical folds. Use the insets to distinguish folds and unfolding cuts. A–D repeat one animal with different tracer overlays. Caption: PDF page 13, printed page 872; panel A: PDF page 11.

Follow the [boundary audit and shape-review pilot](review/boundary_audit.html): reuse shared borders, preserve the narrow extensions of 3a/3b, retain uncertainty bands, and keep any atlas predictions separate. The pilot captures only printed interiors of dorsal M1, 3a and 3b, excluding gray bands; it is not a complete-field area estimate. The original 24 ROIs remain rejected pending retracing. Improved shape guidance does not resolve the missing or ambiguous physical scales.

<!-- project-tracing-review-2026-10-31 -->
## Project-wide tracing review, 31 October 2026

[View this dataset's quality review](../project_review_2026-10-31/index.html?paper=Burman_etal_2008) · [Review methods and changes](../project_review_2026-10-31/README.md)

View-level screening categories: C=4. A identifies the clearest source/fit examples; B retains caveats; C needs targeted review/retracing; D is unsuitable for the intended anatomical area inference; N has no saved trace. These are not individual-region certification or independent-specimen counts. See the linked report for each map's notes and proposed improvements.

Atlases and guides: see the [project guide](../ReadMe.md). Use same-specimen panels to resolve obscured lines where correspondence is established; use other specimens and atlases for field identity, adjacency and sulcal plausibility only. They do not supply an observed border, justify copying a shape, or establish a missing physical scale.
