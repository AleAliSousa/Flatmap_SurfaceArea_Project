"""Reproduce a provisional, image-derived flatmap measurement pilot.

Requires Python, Pillow, numpy, and pypdfium2. ROI vertices are in fig20_rois.json.
The original article and existing source tables are read-only inputs.
"""
from pathlib import Path
import base64
import csv
import hashlib
import html
import json
import math

import numpy as np
import pypdfium2 as pdfium
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT / "fig20_rois.json").read_text())
COLORS = ["#0072b2", "#56b4e9", "#e69f00", "#cc79a7", "#009e73", "#d55e00", "#8a5ab5", "#d6a000", "#208b87", "#8e6f3e", "#4871b2", "#ad5865", "#55853b", "#956497", "#3c8aa2"]


def morph(mask, radius, erode):
    """Binary morphology with a discrete circular kernel; no SciPy dependency."""
    h, w = mask.shape
    pad = np.pad(mask, radius, constant_values=False)
    result = np.ones_like(mask) if erode else np.zeros_like(mask)
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            if dx * dx + dy * dy <= radius * radius:
                view = pad[radius + dy:radius + dy + h, radius + dx:radius + dx + w]
                if erode:
                    result &= view
                else:
                    result |= view
    return result


def silhouette(im, threshold=150, inset=2):
    binary = Image.fromarray(np.uint8(np.array(im.convert("L")) >= threshold) * 255).copy()
    ImageDraw.floodfill(binary, (0, 0), 127)
    enclosed = Image.fromarray(np.uint8(np.array(binary) != 127) * 255).copy()
    ImageDraw.floodfill(enclosed, tuple(DATA["whole"]["seed_xy"]), 128)
    mask = np.array(enclosed) == 128
    assert 450_000 < mask.sum() < 650_000, "Outer contour leaked or incorrect component selected"
    return morph(mask, inset, True)


def polygon_mask(points, shape, supersample=4):
    h, w = shape
    high = Image.new("L", (w * supersample, h * supersample))
    # Shift vertices so sample centers represent pixel cells centered on integers.
    ImageDraw.Draw(high).polygon(
        [(round((x + 0.5) * supersample), round((y + 0.5) * supersample)) for x, y in points], fill=255
    )
    return np.array(high, dtype=np.float32).reshape(h, supersample, w, supersample).mean(axis=(1, 3)) / 255


def source_image():
    doc = pdfium.PdfDocument(DATA["source_pdf"])
    page = doc[DATA["pdf_page"] - 1].render(scale=DATA["render_scale"]).to_pil().convert("RGB")
    image = page.crop(tuple(DATA["crop_xyxy"]))
    image.save(ROOT / "fig20_native.png")
    return image


def main():
    im = source_image()
    total = silhouette(im, DATA["whole"]["threshold"], DATA["whole"]["edge_inset_px"])
    total_px = int(total.sum())
    Image.fromarray(np.uint8(total) * 255).save(ROOT / "fig20_whole_mask.png")
    p1, p2 = DATA["scale"]["endpoints_px"]
    scale_px = math.dist(p1, p2)
    mm_per_pixel = DATA["scale"]["length_mm"] / scale_px
    calibration = mm_per_pixel ** 2
    whole_mm2 = total_px * calibration
    radius = 2
    dscale = DATA["scale"]["length_uncertainty_px"]
    lo_scale = (DATA["scale"]["length_mm"] / (scale_px + dscale)) ** 2
    hi_scale = (DATA["scale"]["length_mm"] / (scale_px - dscale)) ** 2
    whole_low = min(silhouette(im, t, 3).sum() for t in [100, 150, 200]) * lo_scale
    whole_high = max(silhouette(im, t, 1).sum() for t in [100, 150, 200]) * hi_scale
    common = dict(figure=20, pdf_page=26, printed_page=190, specimen="87-53", species="Callithrix jacchus",
                  hemisphere="unspecified single hemisphere", source="Krubitzer & Kaas 1990, Fig. 20",
                  status="provisional image-derived estimate", source_roi_file="fig20_rois.json")
    rows = [dict(common, label="Neocortex outline", name="Total drawn tissue silhouette", area_px2=total_px,
                 area_mm2=whole_mm2, percent_of_drawn_neocortex=100.0,
                 sensitivity_low_mm2=float(whole_low), sensitivity_high_mm2=float(whole_high),
                 boundary=DATA["whole"]["note"])]
    masks = []
    for roi in DATA["rois"]:
        fractional = polygon_mask(roi["points"], total.shape)
        clipped = fractional * total
        outside_px = float((fractional * ~total).sum())
        if not roi.get("clip_to_outer_contour", False):
            assert outside_px / max(float(fractional.sum()), 1) < .015, f"ROI outside cortex: {roi['label']}"
        mask = clipped >= .5
        area_px = float(clipped.sum())
        masks.append(mask)
        low = float(morph(mask, radius, True).sum()) * lo_scale
        high = float((morph(mask, radius, False) & total).sum()) * hi_scale
        rows.append(dict(common, label=roi["label"], name=roi["name"], area_px2=area_px,
                         area_mm2=area_px * calibration, percent_of_drawn_neocortex=100 * area_px / total_px,
                         sensitivity_low_mm2=low, sensitivity_high_mm2=high, boundary=roi["boundary"]))
    for roi in DATA["unmeasured_labels"]:
        rows.append(dict(common, label=roi["label"], name="", area_px2="", area_mm2="",
                         percent_of_drawn_neocortex="", sensitivity_low_mm2="", sensitivity_high_mm2="",
                         status="not measurable from complete boundary", boundary=roi["reason"]))
    fields = ["label", "name", "area_mm2", "percent_of_drawn_neocortex", "sensitivity_low_mm2", "sensitivity_high_mm2",
              "area_px2", "status", "boundary", "species", "specimen", "hemisphere", "figure", "pdf_page",
              "printed_page", "source", "source_roi_file"]
    with (ROOT / "fig20_measurements.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    counts = np.sum(masks, axis=0)
    overlap_px = int((counts > 1).sum())
    # Small raster-boundary overlaps are retained and reported, never hidden.
    interior_counts = np.sum([morph(mask, 1, True) for mask in masks], axis=0)
    assert (interior_counts > 1).sum() == 0, "ROI interiors overlap after removing their shared 1-pixel edges"
    table_ranges = {"17": (15.7, 22.3), "18": (7.5, 9.6), "DL": (3.1, 4.4), "DM": (1.1, 1.8),
                    "DI": (1.7, 2.8), "FST": (1.7, 2.7), "MT": (1.5, 2.3), "MST": (1.1, 1.7)}
    comparison = []
    for row in rows:
        if row["label"] in table_ranges:
            low, high = table_ranges[row["label"]]
            value = row["percent_of_drawn_neocortex"]
            comparison.append(dict(label=row["label"], pilot_percent=value, published_marmoset_min=low,
                                   published_marmoset_max=high, within_published_range=low <= value <= high))
    with (ROOT / "fig20_table1_comparison.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(comparison[0]))
        writer.writeheader(); writer.writerows(comparison)
    audit = dict(source_sha256=hashlib.sha256(Path(DATA["source_pdf"]).read_bytes()).hexdigest(),
                 scale_length_px=scale_px, pixels_per_mm=1 / mm_per_pixel, area_mm2_per_px2=calibration,
                 whole_area_px2=total_px, whole_area_mm2=whole_mm2, roi_overlap_px=overlap_px,
                 total_image_pixels=im.width * im.height, boundary_sensitivity_radius_px=radius,
                 scale_length_sensitivity_px=dscale, shrinkage_correction="none",
                 source_table_matching="species range only; figure specimen ID not linked to numbered Table 1 cases",
                 interpretation="Measurements are of the published flattened reconstruction; unreviewed anatomical traces.")
    (ROOT / "measurement_audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    create_review(im, total, rows, masks, comparison, audit)
    print(json.dumps({"audit": audit, "measurements": [{k: r[k] for k in ["label", "area_mm2", "percent_of_drawn_neocortex"]} for r in rows],
                      "comparison": comparison}, indent=2))


def create_review(im, total, rows, masks, comparison, audit):
    rgba = im.convert("RGBA")
    overlay = Image.new("RGBA", im.size)
    for mask, color in zip(masks, COLORS):
        colored = np.zeros((im.height, im.width, 4), dtype=np.uint8)
        rgb = [int(color[j:j+2], 16) for j in (1, 3, 5)]
        colored[mask] = rgb + [61]
        colored[mask & ~morph(mask, 1, True)] = rgb + [255]
        overlay = Image.alpha_composite(overlay, Image.fromarray(colored))
    boundary = total & ~morph(total, 1, True)
    edge = np.zeros((im.height, im.width, 4), dtype=np.uint8)
    edge[boundary] = [0, 120, 130, 255]
    rgba = Image.alpha_composite(Image.alpha_composite(rgba, overlay), Image.fromarray(edge))
    rgba.convert("RGB").save(ROOT / "fig20_traced.png")
    b64 = base64.b64encode((ROOT / "fig20_native.png").read_bytes()).decode()
    table_rows = []
    paths = []
    for index, (roi, color) in enumerate(zip(DATA["rois"], COLORS)):
        points = " ".join(f"{x},{y}" for x, y in roi["points"])
        paths.append(f'<polygon class="roi" data-i="{index}" points="{points}" fill="{color}" stroke="{color}"><title>{html.escape(roi["label"] + ": " + roi["boundary"])}</title></polygon>')
        row = rows[index + 1]
        table_rows.append(f'<tr data-i="{index}" tabindex="0"><td><span class="dot" style="background:{color}"></span>{html.escape(roi["label"])}</td><td>{row["area_mm2"]:.1f}</td><td>{row["percent_of_drawn_neocortex"]:.2f}%</td><td>{row["sensitivity_low_mm2"]:.1f}–{row["sensitivity_high_mm2"]:.1f}</td></tr>')
    compare_rows = "".join(f'<tr><td>{r["label"]}</td><td>{r["pilot_percent"]:.2f}%</td><td>{r["published_marmoset_min"]:.1f}–{r["published_marmoset_max"]:.1f}%</td><td>{"Within range" if r["within_published_range"] else "Outside range — review"}</td></tr>' for r in comparison)
    mask_b64 = base64.b64encode((ROOT / "fig20_whole_mask.png").read_bytes()).decode()
    svg = f'<svg id="map" viewBox="0 0 {im.width} {im.height}" xmlns="http://www.w3.org/2000/svg"><defs><mask id="cortex" maskUnits="userSpaceOnUse" x="0" y="0" width="{im.width}" height="{im.height}"><image width="{im.width}" height="{im.height}" href="data:image/png;base64,{mask_b64}"/></mask></defs><image width="{im.width}" height="{im.height}" href="data:image/png;base64,{b64}"/><g mask="url(#cortex)">' + "".join(paths) + '</g></svg>'
    body = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Figure 20 · Flatmap measurement pilot</title>
<style>*{box-sizing:border-box}body{margin:0;background:#f5f7fa;color:#182d3d;font:15px/1.5 Arial,sans-serif}header,main,footer{max-width:1450px;margin:auto;padding:24px 32px}header{padding-bottom:8px}h1{font-size:28px;margin:0 0 8px}h2{font-size:19px}p{max-width:1000px}.badge{display:inline-block;font-size:12px;letter-spacing:.06em;color:#95632e;background:#fff2dc;padding:4px 9px;border-radius:4px}.layout{display:grid;grid-template-columns:minmax(500px,1.7fr) minmax(350px,1fr);gap:24px}.card{background:white;border:1px solid #dde5eb;border-radius:12px;padding:18px}svg{width:100%;display:block}.roi{fill-opacity:.16;stroke-width:1.4;cursor:pointer}.roi.active{fill-opacity:.35;stroke-width:3}.hidden .roi{display:none}table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:right;padding:7px;border-bottom:1px solid #e6ebef}td:first-child,th:first-child{text-align:left}tr[data-i]{cursor:pointer}tr.active{background:#e7f4fa}.dot{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:7px}button,a.download{font:inherit;padding:8px 12px;border:1px solid #adc0cc;border-radius:6px;background:#fff;color:#123f57;cursor:pointer;text-decoration:none}.summary{font-size:22px;margin:4px 0}.small{font-size:12px;color:#536879}.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}#detail{min-height:74px;border-top:1px solid #e4e8eb;margin-top:14px;padding-top:12px}.bottom{margin-top:24px}.note{border-left:3px solid #d99440;padding-left:12px}.links{display:flex;gap:10px;flex-wrap:wrap}@media(max-width:950px){.layout{grid-template-columns:1fr}header,main,footer{padding:18px}}</style>
<header><span class="badge">PROVISIONAL · TRACES REQUIRE REVIEW</span><h1>A measurable cortical flatmap</h1><p>Krubitzer &amp; Kaas (1990), Figure 20 · Marmoset <i>Callithrix jacchus</i> · specimen 87-53 · printed page 190 / PDF page 26. This pilot measures one reconstructed hemisphere from the published drawing.</p></header>
<main><div class="layout"><section class="card"><div class="toolbar"><button id="toggle">Hide outlines</button><button id="clear">Clear selection</button></div>SVG_HERE<p class="small">Select an outline or table row to inspect its boundary note. The source scan is embedded at its original crop size; resizing this display does not change measurements.</p></section>
<section class="card"><h2>Total drawn neocortex</h2><p class="summary">WHOLE_HERE mm²</p><p class="small">SENS_HERE mm² under the stated scale and outer-stroke sensitivity scenarios. This is the drawn tissue extent, not a shrinkage-corrected in-vivo area.</p><h2>Labelled cortical fields</h2><table><thead><tr><th>Field</th><th>mm²</th><th>of outline</th><th>Scenario mm²</th></tr></thead><tbody>ROWS_HERE</tbody></table><div id="detail" class="small">Select a field to see which parts of its boundary need review.</div><p class="note"><b>Unmeasured:</b> PP, IT, M and PM lack complete field outlines. Blank values mean unavailable, not zero. “Lateral sulcus” denotes a landmark.</p></section></div>
<section class="card bottom"><h2>Check against the published table</h2><p>Table 1 reports percentages for six marmoset hemispheres. Their numbered cases are not securely linked to specimen 87-53, so these are comparisons with the species range, not specimen-matched validation. No trace was adjusted to force agreement.</p><table><thead><tr><th>Field</th><th>This trace</th><th>Table 1 range</th><th>Screening result</th></tr></thead><tbody>COMPARE_HERE</tbody></table></section>
<section class="card bottom"><h2>Method and limitations</h2><p>The 2 mm scale line spans SCALE_HERE pixels. Area = enclosed pixel area × (2 / SCALE_HERE)². Each named region follows the drawn anatomical border, including tissue under black tracer marks. The whole-tissue mask fills the exterior contour; a 2-pixel inset approximates the centre of its thick stroke. Region masks are clipped to that tissue mask.</p><p>Scenario ranges vary ROI boundaries by ±2 pixels and the calibration length by ±2 pixels; the total-outline scenario also varies the grayscale threshold and stroke inset. These are illustrative sensitivity bounds, not confidence intervals. They do not capture uncertain anatomical interpretation, differential shrinkage, missing cortex or reconstruction error. No correction for histological shrinkage was applied.</p><p>The figure is a reconstruction across sections, not the area of one histological slice. Measurements apply to this drawn hemisphere. Do not double them or treat repeated summary/connection panels as independent animals.</p><div class="links"><a class="download" href="fig20_measurements.csv">Measurement CSV</a><a class="download" href="fig20_rois.json">ROI vertices</a><a class="download" href="fig20_traced.png">Traced image</a><a class="download" href="README.md">Method and figure inventory</a></div></section></main><footer class="small">Pilot only: Figure 20 has been traced. Figures 12–19 and 21–24 have been identified but are not yet measured. All results are image-derived estimates requiring anatomical review.</footer>
<script>const rois=ROIS_HERE;const fields=[...document.querySelectorAll('[data-i]')];function select(i){fields.forEach(e=>e.classList.toggle('active',e.dataset.i===String(i)));document.getElementById('detail').textContent=i===null?'Select a field to see which parts of its boundary need review.':rois[i].label+' · '+rois[i].name+' — '+rois[i].boundary;}fields.forEach(e=>{e.addEventListener('click',()=>select(Number(e.dataset.i)));e.addEventListener('keydown',x=>{if(x.key==='Enter')select(Number(e.dataset.i));});});document.getElementById('clear').onclick=()=>select(null);document.getElementById('toggle').onclick=function(){const hidden=document.getElementById('map').classList.toggle('hidden');this.textContent=hidden?'Show outlines':'Hide outlines';};</script></html>'''
    replacements = {"SVG_HERE": svg, "WHOLE_HERE": f'{rows[0]["area_mm2"]:.1f}',
                    "SENS_HERE": f'{rows[0]["sensitivity_low_mm2"]:.1f}–{rows[0]["sensitivity_high_mm2"]:.1f}',
                    "ROWS_HERE": "".join(table_rows), "COMPARE_HERE": compare_rows,
                    "SCALE_HERE": f'{audit["scale_length_px"]:.3f}', "ROIS_HERE": json.dumps(DATA["rois"])}
    for key, value in replacements.items(): body = body.replace(key, value)
    (ROOT / "fig20_review.html").write_text(body)


if __name__ == "__main__":
    main()
