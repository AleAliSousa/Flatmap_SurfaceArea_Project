# All individual-case flatmaps: Krubitzer & Kaas (1990)

**Complete digitization pass for Figures 12–24: 13 hemisphere outlines and 186 labelled field estimates. Anatomical review remains necessary.**

Use `review_gallery.html` to select a figure, compare its source and colored trace, vary trace opacity, and highlight individual fields from the table. The gallery embeds its source images; it does not transmit them. `flatmap_comparison_book.pdf` provides the same source/trace comparisons in a 13-page portable document. Full-resolution image pairs are retained as `figNN_source.png` and `figNN_traced.png`.

## Data and scope

**ImageJ/Fiji exports are now available in `imagej/`.** Each figure has a calibrated TIFF with editable overlay, native `RoiSet.zip`, and a calibrated binary mask stack. See `imagej/README.md` for opening, editing, mask re-selection and saving. All 199 selections were round-trip checked using ImageJ 1.54p. The maximum field-area difference from the fractional-pixel CSV method is 0.692%; exact per-ROI differences are recorded. The original measurements remain unchanged.

- `all_measurements.csv`: 247 rows: 13 total outlines, 186 traced labels, and 48 labels lacking complete individual boundaries. Missing values are blank, never zero. Of the 199 rows with pixel areas, 187 also have absolute mm².
- `hemisphere_summary.csv`: one row per main case figure, with image and coordinate filenames.
- `figNN_measurements.csv`: each case's complete measurements and boundary notes.
- `figNN_rois.json`: all polygon coordinates, exact figure-specific calibration, mask seed, contour repairs and artifact exclusions.
- `figNN_whole_mask.png`: binary denominator mask; white pixels are included tissue.
- `table1_range_check.csv`: 101 visual-field comparisons with printed species ranges; 25 lie outside those ranges and remain review flags.
- `source_manifest.json`: original PDF path, SHA-256, exact crop geometry and image scaling.
- `paper_figure_inventory.csv`: every numbered figure accounted for. The quantitative set comprises the 13 individual-case whole-cortex reconstructions. Schematic summaries, local histological views, contralateral detail panels and charts are not added as independent whole-hemisphere cases.
- `trace_index_01.jpg` and `trace_index_09.jpg`: overview sheets; use full-resolution PNGs for border review.
- `all_audit.json` and `completion_summary.json`: technical checks and counts.

Figures 12–16 are squirrel monkey, 17–19 owl monkey, 20–21 marmoset, and 22–24 galago. Species names follow the paper. Left/right hemisphere has not been assigned; each main case is treated as one drawn hemisphere, without doubling. Figure specimen IDs are kept separate from the unlinked numbered cases in Table 1.

## Missing calibration and incomplete boundaries

**Figure 19, owl monkey 88-16, has a visible “2 mm” label but no visible scale line**, confirmed in a 432-dpi rendering (`fig19_scale_detail.png`). Its whole-cortex pixel area and field percentages are retained; all absolute mm² cells are blank. No scale is borrowed from another figure, species or orientation arrow.

Labels such as PP and IT usually describe broad territories without closed borders. Some maps also leave parts of 3a, 3b, M, DM/DI-related territory, or V1/V2 open. These cases are explicitly listed as unmeasured rather than extrapolated across substantial gaps. Short gaps between otherwise interpretable boundary segments are interpolated and documented. In Figure 18, V2's dorsal terminus is approximate. In Figure 22, the compartment labelled M includes the UZ recess; UZ has no separate closed perimeter, so it is not counted again. “PV/IG,” “MI,” and “C” retain the printed labels; no unsupported anatomical synonym mapping was applied.

## How the measurements were made

Source pages were rendered at 2.5 pixels per PDF point, cropped, and uniformly reduced to a maximum width of 1,100 pixels for digitization. Figure 20 retains the original approved pilot's 960 × 910 pixel crop and calibration. All rendering and crop transforms are recorded. Physical scale is taken from the line in each image, so uniform resizing cancels in area conversion. Raw pixel areas from different figures must not be compared as physical areas.

For newly digitized maps, each scale stroke was manually located, segmented at grayscale threshold 150, and measured along its principal axis using its full pixel extent. Red crosses in the tracing mark the endpoints. The conversion is:

`area_mm2 = area_px2 * (scale_length_mm / scale_length_px)^2`

The whole-tissue mask is obtained by flood-filling the outside of the drawing, selecting the tissue component, and approximating the centre of the printed outer stroke. A one-pixel barrier dilation bridges antialiasing gaps, followed by a two-pixel circular inset. Small disconnected annotation fragments are removed. Explicit saved exclusions remove attached cut-location arrows. Figure 12 needs a small closure at the damaged tail tip; Figure 14 needs a short contour gap closure. Every such line/exclusion is in the JSON. The whole mask includes dark tracer, light tissue and unnamed cortex, and excludes gaps outside flattened pieces.

Fields were manually digitized against the source. Shared borders were aligned; polygons were checked for self-intersection and material interior overlap. Polygon coverage is calculated at 3× supersampling, or 4× for the original Figure 20 pilot, then clipped to the tissue mask. Tracer dots and injection sites are not subtracted. The total outline is measured independently, rather than by summing labelled areas: the labels do not constitute a complete parcellation.

`sensitivity_low_mm2` and `sensitivity_high_mm2` vary ROI boundaries by ±2 pixels and calibration length by ±2 pixels. The total-outline scenarios vary its boundary by ±1 pixel. These are illustrative **sensitivity scenarios, not statistical confidence intervals**. They do not quantify all uncertainty in dashed borders, anatomically ambiguous limits, tissue processing, shrinkage, missing tissue or reconstruction. No shrinkage correction is applied; these are areas of the published reconstructions, not in-vivo pial surface estimates.

## Comparison with the paper

Table 1, printed p.175 / PDF p.11, reports eight visual fields as percentages of neocortex. The species ranges used here were read from the printed table, rather than assuming the pre-existing local transcription is authoritative. Table case numbers have not been linked securely to figure specimen IDs. Range checks are therefore only screening comparisons, not specimen-matched validation. Traces were never adjusted to force agreement. The 25 out-of-range values are preserved for the user's anatomical comparison.

## Reproduction

Python dependencies: Pillow, numpy, pypdfium2 and reportlab. The original PDF is needed only to regenerate source images; all other steps use saved local artifacts.

```sh
python3 prepare_sources.py --pdf '/path/to/original.pdf'
python3 trace_definitions.py
python3 measure_all.py
python3 build_review.py
python3 verify_outputs.py
```

Edit `trace_definitions.py` for a change intended to survive regeneration. You can also edit the per-figure JSON directly and run `measure_all.py` followed by `build_review.py`; running `trace_definitions.py` again replaces those JSON edits. The pilot coordinates are retained in `pilot_fig20_rois.json`.

The PNG overlays and PDF pages were visually inspected. Numeric invariants, image registration, polygon self-intersections, ROI overlaps and HTML JavaScript syntax were checked. Browser interaction QA is unavailable because the built-in browser blocks local-file URLs; the standalone PDF and image files provide a verified viewing route.

The original PDF, existing source tables, and project-wide surface-area datasets were not modified. These new measurements remain a separate provisional digitization dataset.
