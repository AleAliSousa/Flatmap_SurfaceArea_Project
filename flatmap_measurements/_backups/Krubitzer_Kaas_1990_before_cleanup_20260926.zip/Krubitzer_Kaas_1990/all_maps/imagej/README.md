# Editable ImageJ / Fiji flatmaps

13 figures (12–24), 199 native ImageJ selections: 13 whole-cortex outlines and 186 labelled fields. All are provisional manual traces requiring anatomical review. Source pixels, calibration and ROI-to-mask agreement were checked with the installed ImageJ 1.54p library. No software installation is needed on this Mac: ImageJ and Fiji are already installed.

## Open and edit

1. In ImageJ/Fiji, choose **Plugins > Macros > Run…** and open `Open_flatmap.ijm` from this folder. Choose a figure folder, such as `fig20`. The loader opens the calibrated source and named selections. If ROI Manager already contains work, it stops so you can save that work and clear its list yourself.
2. Click a named region in **ROI Manager**. Use the **Brush Selection Tool** (available from the oval tool's submenu) to refine its boundary: Shift adds to the selection; Option/Alt subtracts. Some selections have many vertices or disconnected components, so the selection brush is usually easier than moving individual vertices. Alternatively draw a replacement polygon/freehand boundary.
3. Click **Update** in ROI Manager to replace the selected entry with your modified boundary. Click **Add** only for a genuinely new region. Show All can be toggled for comparison with the original drawing.
4. In **Analyze > Set Measurements…**, enable Area and Display Label; disable Limit to Threshold. Use ROI Manager **Deselect**, then **Measure**, to measure the entire set on the source image. Twelve figures report mm²; Figure 19 reports pixel². Percent of cortex is `100 × field area / Neocortex outline area`. Labelled fields do not cover all cortex, so do not sum them to obtain the denominator.
5. Save the complete edited set using ROI Manager **Deselect > More > Save…** to a new ZIP filename. Save Results separately using **File > Save As…** from the Results window. A TIFF image alone is not a substitute for saving the updated ROI Manager set. Original CSVs/JSON are not automatically updated by ImageJ edits.

Manual alternative: open `source.tif`, then choose **Image > Overlay > To ROI Manager**. It contains the same editable ROIs as `RoiSet.zip`; import only one of these to avoid duplicates. Another route is ROI Manager **More > Open…** and `RoiSet.zip`. Keep **Restore ROIs centered** disabled, so selections retain their original registration. Use only the matching figure image at its original dimensions. A global scale setting from another image must not override the figure-specific calibration; inspect Image > Properties if results look wrong.

## Re-select or repaint a mask

Open `Masks.tif.zip` with **File > Open…** in ImageJ/Fiji; it is a ZIP-compressed TIFF stack, not an ROI archive. (You can also unzip it and open the TIFF.) Each slice contains one region: 255 is included, 0 is excluded. Slice 1 is the entire cortex; later slices carry the same names/order as ROI Manager. They are separate masks, so overlap/shared edges remain representable.

Choose a slice, set **Image > Adjust > Threshold…** to 255–255, then choose **Edit > Selection > Create Selection**. Press **T** to add that selection to ROI Manager. Activate the matching `source.tif`, click the newly added ROI and refine it against the drawing. Rename it, or use it to replace the old entry without leaving duplicate regions. If you repaint the mask itself first, retain binary values 0 and 255, then repeat Create Selection. Save changed masks under a new name if you want to preserve those edits too.

## What is in each figure folder

| File | Purpose |
|---|---|
| `source.tif` | Exact original image pixels, figure-specific spatial calibration and editable ROI overlay; nothing is drawn permanently into the image. |
| `RoiSet.zip` | Native named `.roi` selections for ROI Manager; includes whole cortex. Selections are already clipped to the cortex. |
| `Masks.tif.zip` | Calibrated binary mask stack, one ROI per named slice, saved by ImageJ. |
| `original_measurements.csv` | Existing measurements, including boundary notes and unmeasurable labels. |
| `original_trace_coordinates.json` | Original sparse manual control points and segmentation settings for reproducibility. Some raw polygons extend outside tissue; the exported ImageJ ROIs are clipped. |
| `calibration_and_labels.json` | Exact original calibration, specimen ID and slice-to-label mapping. |

## Precision and calibration

The initial CSV areas use fractional coverage at 3× supersampling (4× for Figure 20). ImageJ selections here represent the binary masks used in the comparison overlays (coverage at least 50%). All 199 exported selections reproduce these masks **pixel for pixel**, including the exact whole-cortex masks. Field areas therefore differ slightly from the fractional CSV values: the maximum difference is **0.692%** (Figure 12, DM). `imagej_validation.tsv` records every ImageJ baseline area, original fractional area and percentage difference. TIFF spatial-resolution tags introduce only negligible numeric rounding.

Figure 19 remains uncalibrated: the printed “2 mm” label is present but its line is absent in this scan. Its TIFF unit is pixel. The other figures each use their own scale stroke. Figure 17's 2 mm line is 28.012 pixels and Figure 18's is 31.049 pixels in equally resized crops; printed lengths in the PDF are approximately 5.124 and 5.680 mm. Borrowing those two calibrations would yield **1,831 or 1,490 mm²**, respectively, for Figure 19's same whole-cortex mask. These are illustrative assumptions, not accepted measurements, and are not inserted into the dataset. `scale_comparison.csv` removes crop resizing to compare all figures in PDF coordinates. The statement that a scale applies to all figures in the Figure 10 caption concerns its panels, not the later individual-case flatmaps.

`validation_summary.json` and `imagej_version.txt` document the read-back checks: native ROI ZIP decoding, source pixel preservation, TIFF overlay agreement, every binary mask slice, calibrated units and area arithmetic. Interactive GUI operation was not tested; the file contents were verified through ImageJ itself in headless mode. Editing these files does not establish anatomical validity of uncertain boundaries. No shrinkage correction or in-vivo surface conversion is applied.

## Rebuild the exports

The parent folder contains `export_imagej.py`, `ExportImageJ.java`, the source PNGs and measurement scripts. Run `python3 export_imagej.py` there. It uses local Java 17 and the installed Fiji ImageJ JAR; alternate locations can be supplied with `--java` and `--ij-jar`. Re-exporting regenerates `source.tif`, `RoiSet.zip` and mask stacks, so save your edits under other filenames first.

Official instructions: [ROI Manager and area measurement](https://imagej.net/ij/docs/menus/analyze.html#manager), [selection brush and polygon tools](https://imagej.net/ij/docs/guide/146-19.html), [creating selections from masks](https://imagej.net/ij/docs/menus/edit.html).
