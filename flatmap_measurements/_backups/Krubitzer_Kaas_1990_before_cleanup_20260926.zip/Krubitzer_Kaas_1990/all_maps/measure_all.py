"""Recompute all saved figure digitizations and keep source/trace pairs."""
import base64,csv,hashlib,html,json,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFilter

ROOT=Path(__file__).resolve().parent
PALETTE={'17':'#0072b2','18':'#56b4e9','DM':'#e69f00','DI':'#cc79a7','DL':'#009e73','MT':'#d55e00','MST':'#8a5ab5','FST':'#d6a000','3b':'#208b87','3a':'#8e6f3e','1':'#576fa6','2':'#bd6259','SII':'#4871b2','PV/IG':'#ad5865','PV':'#ad5865','AI':'#55853b','FEF':'#956497','FV':'#3c8aa2','Motor & Premotor':'#808040','C':'#9a613c'}

def morph(mask,r,erode):
    h,w=mask.shape;p=np.pad(mask,r,constant_values=False);out=np.ones_like(mask) if erode else np.zeros_like(mask)
    for dy in range(-r,r+1):
        for dx in range(-r,r+1):
            if dx*dx+dy*dy<=r*r:
                q=p[r+dy:r+dy+h,r+dx:r+dx+w]
                if erode:out &= q
                else:out |= q
    return out

def whole_mask(im,d):
    ink=Image.fromarray(np.uint8(np.array(im.convert('L'))<d['threshold'])*255).copy()
    draw=ImageDraw.Draw(ink)
    for line in d.get('whole_repairs',[]):draw.line([tuple(p) for p in line],fill=255,width=2)
    if d['barrier_dilation_px']:ink=ink.filter(ImageFilter.MaxFilter(2*d['barrier_dilation_px']+1))
    white=Image.fromarray(255-np.array(ink)).copy();ImageDraw.floodfill(white,(0,0),127)
    enclosed=Image.fromarray(np.uint8(np.array(white)!=127)*255).copy()
    selected=np.zeros_like(np.array(enclosed),dtype=bool)
    for seed in d['whole_seeds']:
        part=enclosed.copy();ImageDraw.floodfill(part,tuple(seed),128);selected |= np.array(part)==128
    selected=morph(selected,d['edge_inset_px'],True)
    # Remove small arrow/letter components disconnected by the stroke inset.
    pruned=np.zeros_like(selected)
    for seed in d['whole_seeds']:
        component=Image.fromarray(np.uint8(selected)*255).copy()
        if not selected[seed[1],seed[0]]:raise ValueError(f'Whole-tissue seed is outside mask: {seed}')
        ImageDraw.floodfill(component,tuple(seed),128);pruned |= np.array(component)==128
    for polygon in d.get('whole_exclusions',[]):pruned &= poly_mask([polygon],pruned.shape)<.5
    return pruned

def poly_mask(polys,shape,ss=3):
    h,w=shape;im=Image.new('L',(w*ss,h*ss));draw=ImageDraw.Draw(im)
    for poly in polys:draw.polygon([(round((x+.5)*ss),round((y+.5)*ss)) for x,y in poly],fill=255)
    return np.array(im,dtype=np.float32).reshape(h,ss,w,ss).mean(axis=(1,3))/255

def measure(d):
    f=d['figure'];im=Image.open(ROOT/f'fig{f:02d}_source.png').convert('RGB');total=whole_mask(im,d)
    if d.get('whole_manual_polygon'):
        total=poly_mask([d['whole_manual_polygon']],total.shape)>=.5
    calibrated=bool(d.get('scale_endpoints_px'))
    n=int(total.sum());bar=math.dist(*d['scale_endpoints_px']) if calibrated else float('nan');factor=(d['scale_length_mm']/bar)**2
    assert n>20000,f'Figure {f}: open contour / incomplete component ({n} px)'
    Image.fromarray(np.uint8(total)*255).save(ROOT/f'fig{f:02d}_whole_mask.png')
    base=dict(figure=f,pdf_page=d['pdf_page'],printed_page=d['printed_page'],specimen=d['specimen'],species=d['species_as_reported'],hemisphere='not assigned',scale_length_mm=d['scale_length_mm'],scale_length_px=bar,source_roi_file=f'fig{f:02d}_rois.json')
    lo=(d['scale_length_mm']/(bar+2))**2;hi=(d['scale_length_mm']/(bar-2))**2
    rows=[dict(base,label='Neocortex outline',area_px2=n,area_mm2=n*factor,percent_of_drawn_neocortex=100.,sensitivity_low_mm2=float(morph(total,1,True).sum())*lo,sensitivity_high_mm2=float(morph(total,1,False).sum())*hi,status='provisional image-derived estimate',boundary_note='Total drawn tissue, repaired at documented small scan gaps if needed; no shrinkage correction.')]
    rgba=im.convert('RGBA');masks=[];audit=[]
    for r in d['rois']:
        frac=poly_mask(r['polygons'],total.shape,d.get('supersample',3));unclipped=float(frac.sum());frac*=total;px=float(frac.sum());mask=frac>=.5;masks.append(mask)
        outside=unclipped-px
        if outside/max(unclipped,1)>.03 and not r.get('clip_to_tissue'):audit.append(f"{r['label']}: {outside/unclipped:.1%} of polygon clipped at tissue border")
        rows.append(dict(base,label=r['label'],area_px2=px,area_mm2=px*factor,percent_of_drawn_neocortex=100*px/n,sensitivity_low_mm2=float(morph(mask,2,True).sum())*lo,sensitivity_high_mm2=float((morph(mask,2,False)&total).sum())*hi,status='provisional image-derived estimate',boundary_note=r['boundary_note']))
        color=PALETTE.get(r['label'],'#9670b0');rgb=[int(color[i:i+2],16) for i in (1,3,5)];a=np.zeros((im.height,im.width,4),dtype=np.uint8);a[mask]=rgb+[55];a[mask&~morph(mask,1,True)]=rgb+[255];rgba=Image.alpha_composite(rgba,Image.fromarray(a))
    for r in d['unmeasured']:rows.append(dict(base,label=r['label'],area_px2='',area_mm2='',percent_of_drawn_neocortex='',sensitivity_low_mm2='',sensitivity_high_mm2='',status='not measurable from complete field boundary',boundary_note=r['reason']))
    edge=np.zeros((im.height,im.width,4),dtype=np.uint8);edge[total&~morph(total,1,True)]=[0,125,135,255];rgba=Image.alpha_composite(rgba,Image.fromarray(edge))
    # Calibration endpoints are shown separately from areal outlines.
    dr=ImageDraw.Draw(rgba)
    for x,y in d.get('scale_endpoints_px',[]):dr.line([(x-4,y),(x+4,y)],fill='#c00035',width=1);dr.line([(x,y-4),(x,y+4)],fill='#c00035',width=1)
    rgba.convert('RGB').save(ROOT/f'fig{f:02d}_traced.png')
    overlaps=[]
    for i in range(len(masks)):
        for j in range(i+1,len(masks)):
            inter=morph(masks[i],1,True)&morph(masks[j],1,True);count=int(inter.sum())
            if count>5:overlaps.append(dict(a=d['rois'][i]['label'],b=d['rois'][j]['label'],interior_overlap_px=count))
    if not calibrated:
        audit.append(d.get('scale_note','Missing scale line; absolute areas unavailable.'))
        for row in rows:
            for key in ['area_mm2','sensitivity_low_mm2','sensitivity_high_mm2','scale_length_px']:row[key]=''
            if row['area_px2']!='':row['status']='provisional pixels and proportions only; no visible calibration line'
    summary=dict(figure=f,specimen=d['specimen'],total_area_mm2=n*factor if calibrated else None,total_pixels=n,scale_length_px=bar if calibrated else None,measured_fields=len(d['rois']),missing_fields=len(d['unmeasured']),warnings=audit,overlaps=overlaps)
    return rows,summary

def write_csv(path,rows):
    with path.open('w',newline='') as fp:
        writer=csv.DictWriter(fp,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('figures',nargs='*',type=int);args=ap.parse_args()
    rows=[];audit=[]
    for p in sorted(ROOT.glob('fig??_rois.json')):
        d=json.loads(p.read_text())
        if args.figures and d['figure'] not in args.figures:continue
        rr,aa=measure(d);write_csv(ROOT/f"fig{d['figure']:02d}_measurements.csv",rr);rows.extend(rr);audit.append(aa);print(json.dumps(aa))
    if not args.figures:
        write_csv(ROOT/'all_measurements.csv',rows);(ROOT/'all_audit.json').write_text(json.dumps(audit,indent=2)+'\n')

if __name__=='__main__':main()
