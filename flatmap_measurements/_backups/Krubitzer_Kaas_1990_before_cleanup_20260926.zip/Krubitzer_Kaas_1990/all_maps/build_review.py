"""Build the comparison gallery, PDF contact book, provenance and tables."""
from pathlib import Path
import base64,csv,hashlib,html,json,math,shutil
from PIL import Image,ImageDraw,ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A3,landscape
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parent
RANGES={
 'Saimiri sciureus':{'17':[13.7,19.9],'18':[6.5,9.4],'DL':[3.4,5.7],'DM':[1.2,1.8],'DI':[.9,1.4],'FST':[2.4,3.2],'MT':[1.1,1.6],'MST':[1.1,1.8]},
 'Aotus trivirgatus':{'17':[6.7,18.4],'18':[5.,9.2],'DL':[2.2,4.2],'DM':[1.5,2.4],'DI':[1.3,1.8],'FST':[1.2,2.1],'MT':[1.3,2.1],'MST':[1.1,1.8]},
 'Callithrix jacchus':{'17':[15.7,22.3],'18':[7.5,9.6],'DL':[3.1,4.4],'DM':[1.1,1.8],'DI':[1.7,2.8],'FST':[1.7,2.7],'MT':[1.5,2.3],'MST':[1.1,1.7]},
 'Galago senegalensis':{'17':[13.5,19.6],'18':[4.4,8.0],'DL':[2.,2.9],'DM':[.6,1.2],'DI':[.7,1.4],'FST':[1.8,2.7],'MT':[1.9,2.5],'MST':[1.4,2.2]}}

def csvout(name,rows):
    with (ROOT/name).open('w',newline='') as fp:
        w=csv.DictWriter(fp,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def datauri(path):return 'data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()

def n(v,places=1):return f'{float(v):.{places}f}' if v!='' else 'unavailable'

def main():
    rows=list(csv.DictReader((ROOT/'all_measurements.csv').open()))
    audits=json.loads((ROOT/'all_audit.json').read_text());maps=[];summary=[];comparisons=[]
    for fig in range(12,25):
        d=json.loads((ROOT/f'fig{fig:02d}_rois.json').read_text());rr=[r for r in rows if int(r['figure'])==fig];total=rr[0]
        a=next(x for x in audits if x['figure']==fig)
        summary.append(dict(figure=fig,pdf_page=fig+6,printed_page=fig+170,specimen=d['specimen'],species=d['species_as_reported'],
            neocortex_mm2=total['area_mm2'],neocortex_pixels=total['area_px2'],measured_fields=a['measured_fields'],unmeasured_labels=a['missing_fields'],
            calibration='visible scale line' if d['scale_endpoints_px'] else 'line absent; proportions only',
            source_image=f'fig{fig:02d}_source.png',traced_image=f'fig{fig:02d}_traced.png',roi_vertices=f'fig{fig:02d}_rois.json',status='provisional, trace review required'))
        for row in rr:
            if row['label'] in RANGES[row['species']] and row['percent_of_drawn_neocortex']:
                low,high=RANGES[row['species']][row['label']];pct=float(row['percent_of_drawn_neocortex'])
                comparisons.append(dict(figure=fig,specimen=row['specimen'],species=row['species'],field=row['label'],digitized_percent=pct,
                    printed_species_min=low,printed_species_max=high,within_species_range=low<=pct<=high,
                    comparison_type='species range only; Table 1 case identities not matched'))
        maps.append(dict(figure=fig,metadata=d,rows=rr,source=datauri(ROOT/f'fig{fig:02d}_source.png'),trace=datauri(ROOT/f'fig{fig:02d}_traced.png'),
                         mask=datauri(ROOT/f'fig{fig:02d}_whole_mask.png'),size=list(Image.open(ROOT/f'fig{fig:02d}_source.png').size)))
    csvout('hemisphere_summary.csv',summary);csvout('table1_range_check.csv',comparisons)
    build_html(maps,rows);build_pdf(maps)
    # Compact visual index for quick inspection; full-resolution PNGs remain the primary traces.
    tiles=[]
    font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',16)
    for m in maps:
        im=Image.open(ROOT/f"fig{m['figure']:02d}_traced.png");im.thumbnail((340,340));tile=Image.new('RGB',(370,385),'white');tile.paste(im,((370-im.width)//2,36))
        draw=ImageDraw.Draw(tile);draw.text((12,9),f"Fig. {m['figure']} | {m['metadata']['specimen']}",fill='#193443',font=font);tiles.append(tile)
    for start in [0,8]:
        batch=tiles[start:start+8];sheet=Image.new('RGB',(370*4,385*math.ceil(len(batch)/4)),'#e5eaf0')
        for i,t in enumerate(batch):sheet.paste(t,((i%4)*370,(i//4)*385))
        sheet.save(ROOT/f'trace_index_{start+1:02d}.jpg',quality=92)
    stats=dict(hemispheres=len(maps),traced_fields=sum(len(m['metadata']['rois']) for m in maps),whole_outlines=len(maps),
        absolute_area_rows=sum(r['area_mm2']!='' for r in rows),pixel_area_rows=sum(r['area_px2']!='' for r in rows),
        unmeasured_rows=sum(r['area_px2']=='' for r in rows),range_checks=len(comparisons),outside_species_range=sum(not r['within_species_range'] for r in comparisons))
    (ROOT/'completion_summary.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats,indent=2))

def build_html(maps,rows):
    content='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Krubitzer & Kaas · all case flatmaps</title>
<style>*{box-sizing:border-box}body{margin:0;color:#183243;background:#f2f5f7;font:15px/1.5 Arial,sans-serif}header,main,footer{max-width:1500px;margin:auto;padding:24px}h1{margin:4px 0;font-size:29px}h2{margin:8px 0;font-size:19px}.tag{font-size:12px;letter-spacing:.06em;color:#9a642c;background:#fff0d7;padding:5px 9px;border-radius:4px}.small{font-size:13px;color:#566d7a}.bar{display:flex;gap:16px;flex-wrap:wrap;align-items:center}.card{background:white;border:1px solid #dce5e9;border-radius:10px;padding:18px;margin:14px 0}.views{display:grid;grid-template-columns:1fr 1fr;gap:20px}.frame{position:relative}.frame img{width:100%;display:block}.frame .overlay,.frame svg{position:absolute;inset:0;width:100%;height:100%}.frame svg{pointer-events:none}select,button{font:inherit;padding:8px 12px;border:1px solid #aebfc9;border-radius:6px;background:white;color:#173e55}a{color:#12688c}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:8px;text-align:left;border-bottom:1px solid #e3e9ec}td.num,th.num{text-align:right}tr[data-label]{cursor:pointer}tr.active{background:#e6f3f8}.alert{padding:10px 14px;border-left:4px solid #d99139;background:#fff4e3}.columns{display:grid;grid-template-columns:1.4fr 1fr;gap:22px}.links{display:flex;gap:18px;flex-wrap:wrap}.nowrap{white-space:nowrap}@media(max-width:900px){.views,.columns{grid-template-columns:1fr}header,main,footer{padding:14px}}</style>
<header><span class="tag">PROVISIONAL IMAGE-DERIVED MEASUREMENTS</span><h1>13 reconstructed hemispheres, with every trace retained</h1><p>Krubitzer &amp; Kaas (1990), individual-case Figures 12–24. Compare each published image with its saved tracing. Every field estimate links to its boundary note; missing boundaries remain unmeasured.</p><div class="links"><a href="all_measurements.csv">All measurement rows</a><a href="hemisphere_summary.csv">Hemisphere summary</a><a href="flatmap_comparison_book.pdf">Source/trace comparison PDF</a><a href="README.md">Methods and limitations</a></div></header>
<main><section class="card"><div class="bar"><label>Figure <select id="figure"></select></label><label>Trace opacity <input id="opacity" type="range" min="0" max="1" step="0.05" value="1"></label><button id="clear">Clear field highlight</button></div><h2 id="title"></h2><p id="meta" class="small"></p><div id="calibration"></div><div class="views"><div><h2>Published image</h2><div class="frame"><img id="source" alt="Original published flatmap"></div></div><div><h2>Saved trace</h2><div class="frame"><img id="base" alt="Original flatmap under trace"><img id="trace" class="overlay" alt="Traced cortical fields and total outline"><svg id="highlight"></svg></div></div></div><p class="small">Turquoise: whole-tissue outline. Red crosses: measured scale endpoints. Colors identify fields; unfilled cortex is included in the total. Move opacity to zero to reveal the source beneath the tracing.</p></section>
<div class="columns"><section class="card"><h2>Measurements</h2><table><thead><tr><th>Field</th><th class="num">mm²</th><th class="num">% of outline</th><th>Boundary / status</th></tr></thead><tbody id="rows"></tbody></table></section><section class="card"><h2>Selected field</h2><p id="detail">Select a table row to highlight its polygon.</p><h2>Interpretation</h2><p>All results measure the printed flattened reconstruction of one hemisphere. No correction for shrinkage or missing tissue is applied. Tracer dots and injection sites remain inside the anatomical ROI.</p><p>Some dashed and obscured borders need anatomical review. Proportions can be compared with the published species ranges in <a href="table1_range_check.csv">Table 1 checks</a>; the original numbered table cases have not been matched to these specimen IDs. Out-of-range values are retained as review flags, not forced into agreement.</p><p>CSV sensitivity columns vary ROI boundaries by ±2 pixels and scale length by ±2 pixels (total-outline boundary ±1 pixel). These are scenarios, not confidence intervals, and do not cover every anatomical or processing uncertainty.</p><p id="files" class="links"></p><p class="small">Individual PNGs, binary total masks, editable ROI JSON, extraction metadata and reproduction scripts are included in the same folder. Raw pixel areas from different figure resolutions must not be compared directly.</p></section></div></main><footer class="small">Scope: all 13 individual-case whole-cortex flatmaps. Schematic, partial-section and contralateral-detail panels are inventoried separately; they are not added as independent whole-hemisphere specimens.</footer>
<script>const maps=MAPS_DATA;const byId=id=>document.getElementById(id);let current;const num=(x,n=1)=>x===''?'—':Number(x).toFixed(n);const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
maps.forEach(m=>{const o=document.createElement('option');o.value=m.figure;o.textContent=m.figure+' · '+m.metadata.specimen+' · '+m.metadata.species_as_reported;byId('figure').appendChild(o);});
function highlight(label){document.querySelectorAll('#rows tr').forEach(r=>r.classList.toggle('active',r.dataset.label===label));const row=current.rows.find(r=>r.label===label);byId('detail').textContent=row?label+' — '+row.boundary_note:'Select a table row to highlight its polygon.';const roi=current.metadata.rois.find(r=>r.label===label);const s=byId('highlight');s.setAttribute('viewBox','0 0 '+current.size.join(' '));s.innerHTML='';if(roi){s.innerHTML='<defs><mask id="tissue" maskUnits="userSpaceOnUse" x="0" y="0" width="'+current.size[0]+'" height="'+current.size[1]+'"><image width="'+current.size[0]+'" height="'+current.size[1]+'" href="'+current.mask+'"/></mask></defs><g mask="url(#tissue)">'+roi.polygons.map(p=>'<polygon points="'+p.map(v=>v.join(',')).join(' ')+'" fill="#ffcc33" fill-opacity="0.12" stroke="#b40042" stroke-width="3"/>').join('')+'</g>';}}
function render(){current=maps.find(m=>m.figure===Number(byId('figure').value));const d=current.metadata,t=current.rows[0];byId('title').textContent='Figure '+d.figure+' · '+d.species_as_reported+' · '+d.specimen;byId('meta').textContent='PDF page '+d.pdf_page+' / printed page '+d.printed_page+' · '+d.rois.length+' traced fields · hemisphere side not assigned';byId('source').src=current.source;byId('base').src=current.source;byId('trace').src=current.trace;byId('calibration').innerHTML=t.area_mm2!==''?'<p>Total drawn neocortex: <b>'+num(t.area_mm2)+' mm²</b> · '+d.scale_length_mm+' mm calibration line.</p>':'<p class="alert">The 2 mm label is present, but its scale line is absent. Absolute mm² are unavailable; pixels and cortex percentages are retained.</p>';byId('rows').innerHTML=current.rows.map(r=>'<tr data-label="'+esc(r.label)+'"><td>'+esc(r.label)+'</td><td class="num nowrap">'+num(r.area_mm2)+'</td><td class="num">'+num(r.percent_of_drawn_neocortex,2)+'</td><td>'+esc(r.boundary_note)+'</td></tr>').join('');document.querySelectorAll('#rows tr').forEach(r=>r.onclick=()=>highlight(r.dataset.label));const f=String(d.figure).padStart(2,'0');byId('files').innerHTML='<a href="fig'+f+'_source.png">Source PNG</a><a href="fig'+f+'_traced.png">Trace PNG</a><a href="fig'+f+'_rois.json">ROI coordinates</a>';highlight(null);}
byId('figure').onchange=render;byId('opacity').oninput=()=>byId('trace').style.opacity=byId('opacity').value;byId('clear').onclick=()=>highlight(null);byId('figure').value='12';render();</script></html>'''
    (ROOT/'review_gallery.html').write_text(content.replace('MAPS_DATA',json.dumps(maps,separators=(',',':'))))

def build_pdf(maps):
    w,h=landscape(A3);pdf=canvas.Canvas(str(ROOT/'flatmap_comparison_book.pdf'),pagesize=(w,h));pdf.setTitle('Krubitzer & Kaas 1990: source and traced flatmaps');pdf.setAuthor('Image-derived measurement review')
    for m in maps:
        d=m['metadata'];fig=m['figure'];total=m['rows'][0]
        pdf.setFillColorRGB(.08,.18,.24);pdf.setFont('Helvetica-Bold',19);pdf.drawString(25,h-34,f"Figure {fig} | {d['species_as_reported']} | specimen {d['specimen']}")
        pdf.setFont('Helvetica',10);pdf.drawString(25,h-52,f"Printed p.{d['printed_page']} / PDF p.{d['pdf_page']} | PROVISIONAL | One reconstructed hemisphere; side not assigned")
        if total['area_mm2']:
            title=f"Total drawn neocortex: {n(total['area_mm2'])} mm2 | Scale: {d['scale_length_mm']} mm / {float(total['scale_length_px']):.2f} px"
        else:title='No visible scale line: absolute areas unavailable; pixel areas and cortex fractions retained.'
        pdf.drawString(25,h-68,title)
        left=25;cw=430;top=h-99;maxh=h-164
        for ix,kind in enumerate(['source','traced']):
            x=left+ix*(cw+15);pdf.setFont('Helvetica-Bold',11);pdf.drawString(x,top+8,'Published source' if ix==0 else 'Saved field tracing')
            image=Image.open(ROOT/f'fig{fig:02d}_{kind}.png')
            bx=Image.open(ROOT/f'fig{fig:02d}_whole_mask.png').getbbox()
            if bx:image=image.crop((max(0,bx[0]-12),max(0,bx[1]-12),min(image.width,bx[2]+12),min(image.height,bx[3]+12)))
            scale=min(cw/image.width,maxh/image.height);iw=image.width*scale;ih=image.height*scale
            pdf.drawImage(ImageReader(image),x+(cw-iw)/2,top-ih,width=iw,height=ih,mask='auto')
        x=925;y=top;pdf.setFont('Helvetica-Bold',10);pdf.drawString(x,y,'Field');pdf.drawRightString(w-82,y,'mm2');pdf.drawRightString(w-25,y,'% cortex');y-=19
        for row in m['rows']:
            label='Total outline' if row['label']=='Neocortex outline' else row['label'];pdf.setFont('Helvetica',9)
            pdf.drawString(x,y,label);pdf.drawRightString(w-82,y,n(row['area_mm2']) if row['area_mm2'] else '--');pdf.drawRightString(w-25,y,n(row['percent_of_drawn_neocortex'],2) if row['percent_of_drawn_neocortex'] else '--');y-=17
        pdf.setFont('Helvetica',8);notes=['Blank values are unavailable, not zero.','Colors show field ROIs; turquoise is total tissue.','Black tracer is included, not subtracted.','All coordinates and boundary notes are in CSV/JSON.','No shrinkage correction. Review anatomy before use.']
        for line in notes:pdf.drawString(x,y-12,line);y-=13
        pdf.setFont('Helvetica',9);pdf.drawString(25,34,'Compare with full-resolution PNGs and selectable HTML gallery. Dashed, obscured and open boundaries are documented individually.')
        pdf.drawRightString(w-25,20,f'{fig-11} / 13');pdf.showPage()
    pdf.save()

if __name__=='__main__':main()
