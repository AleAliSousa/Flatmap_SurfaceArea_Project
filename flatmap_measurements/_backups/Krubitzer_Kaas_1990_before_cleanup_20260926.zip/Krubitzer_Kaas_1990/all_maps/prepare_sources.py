"""Re-extract every source image at its saved pixel geometry."""
from pathlib import Path
import argparse,hashlib,json
import pypdfium2 as pdfium
from PIL import Image

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'source_manifest.json').read_text())
parser=argparse.ArgumentParser();parser.add_argument('--pdf',default=manifest['source_pdf']);args=parser.parse_args()
path=Path(args.pdf)
if hashlib.sha256(path.read_bytes()).hexdigest()!=manifest['source_sha256']:
    raise ValueError('PDF hash differs from the digitized source. Check registration before reusing coordinates.')
doc=pdfium.PdfDocument(str(path))
for d in manifest['crops']:
    im=doc[d['pdf_page']-1].render(scale=d['pdf_render_scale']).to_pil().convert('RGB').crop(tuple(d['crop_xyxy']))
    if list(im.size)!=d['source_size']:im=im.resize(tuple(d['source_size']),Image.Resampling.LANCZOS)
    im.save(ROOT/f"fig{d['figure']:02d}_source.png")
print('Re-extracted 13 source crops at the saved coordinates.')
