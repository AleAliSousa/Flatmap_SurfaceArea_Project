"""Export native editable ImageJ ROIs and calibrated images using installed ImageJ.

No original measurements are overwritten. Field selections use the same >=50%
pixel coverage masks as the saved overlays; whole-cortex selections are exact.
"""
import argparse, csv, json, math, shutil, subprocess, tempfile
from pathlib import Path
import numpy as np
from PIL import Image
from measure_all import poly_mask, PALETTE

ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--java', default='/Library/Java/JavaVirtualMachines/zulu-17.jdk/Contents/Home/bin/java')
    ap.add_argument('--ij-jar', default=None)
    args=ap.parse_args()
    if args.ij_jar is None:
        jars=sorted(Path('/Applications/Fiji.app/jars').glob('ij-[0-9]*.jar'))
        if len(jars)!=1:
            raise FileNotFoundError('Provide --ij-jar with the installed ImageJ JAR path.')
        args.ij_jar=str(jars[0])
    out=ROOT/'imagej'; out.mkdir(exist_ok=True)
    comparisons=[]
    crops={c['figure']:c for c in json.loads((ROOT/'crop_metadata.json').read_text())}
    with tempfile.TemporaryDirectory(prefix='krubitzer_imagej_') as temporary:
        tmp=Path(temporary); jobs=[]
        for f in range(12,25):
            d=json.loads((ROOT/f'fig{f}_rois.json').read_text())
            source=ROOT/f'fig{f}_source.png'
            whole=np.asarray(Image.open(ROOT/f'fig{f}_whole_mask.png'))>0
            endpoints=d['scale_endpoints_px']; bar=math.dist(*endpoints) if endpoints else None
            size=d['scale_length_mm']/bar if bar else 1.; unit='mm' if bar else 'pixel'
            saved={r['label']:r for r in csv.DictReader((ROOT/f'fig{f}_measurements.csv').open())}
            selections=[('Neocortex outline',whole)]+[(r['label'],(poly_mask(r['polygons'],whole.shape,d.get('supersample',3))*whole)>=.5) for r in d['rois']]
            for i,(label,mask) in enumerate(selections):
                p=tmp/f'fig{f}_{i:02d}.png'; Image.fromarray(mask.astype('uint8')*255).save(p)
                jobs.append([f,i,label,str(source),str(p),size,unit,saved[label]['area_px2'],PALETTE.get(label,'#007d87' if i==0 else '#9670b0')])
            folder=out/f'fig{f}'; folder.mkdir(exist_ok=True)
            shutil.copy2(ROOT/f'fig{f}_measurements.csv',folder/'original_measurements.csv')
            shutil.copy2(ROOT/f'fig{f}_rois.json',folder/'original_trace_coordinates.json')
            meta={'figure':f,'specimen':d['specimen'],'species':d['species_as_reported'],
                  'pixel_width':size,'pixel_height':size,'unit':unit,'scale_length_mm':d['scale_length_mm'],
                  'scale_endpoints_px':endpoints,'calibrated':bool(endpoints),
                  'roi_count':len(selections),'mask_stack_slices':[{'slice':i+1,'roi_index':i,'label':r[0]} for i,r in enumerate(selections)]}
            (folder/'calibration_and_labels.json').write_text(json.dumps(meta,indent=2)+'\n')
            c=crops[f]; points=bar/(c['resize_scale']*c['pdf_render_scale']) if bar else None
            comparisons.append({'figure':f,'specimen':d['specimen'],'bar_tissue_mm':d['scale_length_mm'],
                                'bar_in_saved_image_pixels':bar,'resize_scale':c['resize_scale'],
                                'bar_length_pdf_points':points,'bar_length_printed_mm':points*25.4/72 if points else None,
                                'tissue_mm_per_pdf_point':d['scale_length_mm']/points if points else None,
                                'status':'measured scale stroke' if bar else 'no visible scale stroke; not calibrated'})
        jobfile=tmp/'jobs.tsv'
        with jobfile.open('w',newline='') as fp:
            wr=csv.writer(fp,delimiter='\t');wr.writerow(['figure','index','label','source','mask','pixel_size','unit','original_pixels','color']);wr.writerows(jobs)
        subprocess.run([args.java,'-Djava.awt.headless=true','-cp',args.ij_jar,str(ROOT/'ExportImageJ.java'),str(jobfile),str(out)],check=True)
    with (out/'scale_comparison.csv').open('w',newline='') as fp:
        wr=csv.DictWriter(fp,fieldnames=list(comparisons[0]));wr.writeheader();wr.writerows(comparisons)
    rows=list(csv.DictReader((out/'imagej_validation.tsv').open(),delimiter='\t'))
    maximum=max(rows,key=lambda r:abs(float(r['pixel_difference_percent'])))
    summary={'figures':13,'native_ROIs':len(rows),'all_mask_ROI_TIFF_roundtrips_exact':all(r['roi_roundtrip_pixels_equal']=='true' for r in rows),
             'calibrated_figures':12,'uncalibrated_figure':19,
             'largest_absolute_binary_vs_original_area_difference_percent':abs(float(maximum['pixel_difference_percent'])),
             'largest_difference_figure':int(maximum['figure']),'largest_difference_label':maximum['label'],
             'source_measurements_unchanged':True,'gui_interaction_tested':False}
    (out/'validation_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
