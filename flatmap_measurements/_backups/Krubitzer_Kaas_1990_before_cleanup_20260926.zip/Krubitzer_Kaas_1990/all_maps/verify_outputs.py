"""Check scientific data invariants and trace/source registration."""
from pathlib import Path
import csv,json,math
from PIL import Image

ROOT=Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT/'all_measurements.csv').open()))
assert {int(r['figure']) for r in rows}==set(range(12,25))
audits=json.loads((ROOT/'all_audit.json').read_text())
assert len(audits)==13 and all(not a['overlaps'] for a in audits)
for f in range(12,25):
    rr=[r for r in rows if int(r['figure'])==f];total=next(r for r in rr if r['label']=='Neocortex outline')
    assert len({r['label'] for r in rr})==len(rr)
    dims=[Image.open(ROOT/f'fig{f:02d}_{suffix}.png').size for suffix in ['source','traced','whole_mask']]
    assert len(set(dims))==1
    d=json.loads((ROOT/f'fig{f:02d}_rois.json').read_text())
    assert d['specimen']==total['specimen']
    for r in rr:
        if not r['area_px2']:
            assert not r['area_mm2'] and not r['percent_of_drawn_neocortex']
            continue
        px=float(r['area_px2']);den=float(total['area_px2']);pct=float(r['percent_of_drawn_neocortex'])
        assert 0<px<=den and math.isclose(pct,100*px/den,rel_tol=1e-9)
        if d['scale_endpoints_px']:
            factor=(d['scale_length_mm']/math.dist(*d['scale_endpoints_px']))**2
            area=float(r['area_mm2']);assert math.isclose(area,px*factor,rel_tol=1e-9)
            assert float(r['sensitivity_low_mm2'])<=area<=float(r['sensitivity_high_mm2'])
        else:assert f==19 and r['area_mm2']==''
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    for roi in d['rois']:
        for p in roi['polygons']:
            for i in range(len(p)):
                a,b=p[i],p[(i+1)%len(p)]
                for j in range(i+2,len(p)):
                    if i==0 and j==len(p)-1:continue
                    c,e=p[j],p[(j+1)%len(p)]
                    assert not(cross(a,b,c)*cross(a,b,e)<0 and cross(c,e,a)*cross(c,e,b)<0),(f,roi['label'],'self-intersection')
print('PASS: all 13 cases; 186 polygon ROIs; source/trace dimensions; closed polygon geometry; calibration, proportions and missing-value semantics; no material ROI interior overlaps.')
