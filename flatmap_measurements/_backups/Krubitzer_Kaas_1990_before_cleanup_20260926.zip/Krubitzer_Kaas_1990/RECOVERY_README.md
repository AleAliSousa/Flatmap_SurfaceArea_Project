# Recovered flatmap measurements — Krubitzer & Kaas (1990)

Restored on 2026-09-26 to the OneDrive project folder requested by the user:

`/Users/crossmodal/Library/CloudStorage/OneDrive-AllenInstitute/Evo-M1-Trait-Data-restricted/unpublished_data/____Unpublished__ProjectKaskan/flatmap_measurements/Krubitzer_Kaas_1990`

## Start here

- **all_maps/all_measurements.csv** — all measurements and boundary notes; opens in Excel or a text editor.
- **all_maps/hemisphere_summary.csv** — one row per case.
- **all_maps/flatmap_comparison_book.pdf** — original drawing beside its tracing for all 13 cases.
- **all_maps/imagej/README.md** — opening, editing, reselecting masks and saving in ImageJ/Fiji.
- **all_maps/imagej/fig12** through **fig24** — calibrated source TIFF, named ROI ZIP and binary mask stack for each figure.
- **Krubitzer_Kaas_1990_ImageJ.zip** — portable archive of the full comparison/data/ImageJ set.
- **source_paper.pdf** — an unchanged copy of the original article.

## What was recovered

The earlier working folder was no longer present. Original source-file edits, manual polygon coordinates and processing scripts were recovered from this chat's saved execution history. The unchanged article was used to regenerate source crops and outputs. No anatomical borders were redrawn and no measurements were newly inferred during recovery.

The regenerated all_measurements.csv matches the original file's SHA-256 exactly:

`c9b8bb30ab662a3507cfb5277562605adbc3af2af58bb658e4cdb32bfe7a1511`

The package contains 13 hemisphere outlines and 186 labelled field selections. All native ImageJ selections were checked for exact binary-mask agreement using the installed ImageJ library. See all_maps/recovery_verification.json and all_maps/imagej/validation_summary.json. PDF container metadata and ZIP timestamps may differ after regeneration, while measurement values and recovered ROI definitions are preserved.

Figure 19 still has no verified absolute calibration. Unclosed/uncertain field boundaries remain missing. Anatomical review is still needed, and the original methods/uncertainty notes are retained. ImageJ field areas can differ by up to 0.692% from the fractional-pixel CSV estimates, as previously documented.

## Storage and reproducibility

These are ordinary local files inside your OneDrive folder. No Git commit is needed to open or use them. OneDrive controls cloud synchronization; the recovery process verifies the local copies, not completion of cloud upload.

The main reproduction scripts are in all_maps/. The original PDF path in source_manifest.json remains recorded for provenance; if that path becomes unavailable, run prepare_sources.py --pdf ../source_paper.pdf. Re-exporting overwrites generated baseline ROI files, so save your own edited selections under new names.

The existing project-wide surface-area tables were not modified. recovery_checksums.json records hashes for this recovered delivery. All recovered source scripts and tracing coordinates are retained alongside the outputs; the original chat transcript is not included.

Fiji had been upgraded since the first export. The exporter now detects the installed ImageJ JAR instead of assuming the previous version; recovery validation used ImageJ 1.54p. Tracing and measurement algorithms are unchanged.
