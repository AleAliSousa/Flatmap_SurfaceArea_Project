# Flatmap digitization: all 13 individual-case maps

The full set is in **all_maps/**: 13 hemisphere outlines and 186 traced field estimates, with each published image retained beside its tracing. All estimates remain provisional pending anatomical review.

- [Comparison PDF](all_maps/flatmap_comparison_book.pdf)
- [Selectable source/trace gallery](all_maps/review_gallery.html)
- [All measurements](all_maps/all_measurements.csv)
- [Hemisphere summary](all_maps/hemisphere_summary.csv)
- [Methods and limitations](all_maps/README.md)
- [Paper-wide figure inventory](all_maps/paper_figure_inventory.csv)
- [Editable ImageJ/Fiji files and instructions](all_maps/imagej/README.md)
- [ImageJ/Fiji package ZIP](Krubitzer_Kaas_1990_ImageJ.zip)

**Figure 19 has no visible scale line:** its absolute areas are unavailable; pixel areas and percentages are retained. Open/unrecoverable field boundaries are recorded as missing. The original Figure 20 pilot files remain available.

| Figure | Specimen | Species | Neocortex mm² | Source | Trace |
|---|---|---|---:|---|---|
| 12 | 87-35 | Saimiri sciureus | 2925.4 | [PNG](all_maps/fig12_source.png) | [PNG](all_maps/fig12_traced.png) |
| 13 | 87-16 | Saimiri sciureus | 3319.9 | [PNG](all_maps/fig13_source.png) | [PNG](all_maps/fig13_traced.png) |
| 14 | 86-23 | Saimiri sciureus | 3078.6 | [PNG](all_maps/fig14_source.png) | [PNG](all_maps/fig14_traced.png) |
| 15 | 87-15 | Saimiri sciureus | 2951.3 | [PNG](all_maps/fig15_source.png) | [PNG](all_maps/fig15_traced.png) |
| 16 | 87-25 | Saimiri sciureus | 2135.0 | [PNG](all_maps/fig16_source.png) | [PNG](all_maps/fig16_traced.png) |
| 17 | 88-7 | Aotus trivirgatus | 1812.7 | [PNG](all_maps/fig17_source.png) | [PNG](all_maps/fig17_traced.png) |
| 18 | 87-54 | Aotus trivirgatus | 1467.7 | [PNG](all_maps/fig18_source.png) | [PNG](all_maps/fig18_traced.png) |
| 19 | 88-16 | Aotus trivirgatus | unavailable | [PNG](all_maps/fig19_source.png) | [PNG](all_maps/fig19_traced.png) |
| 20 | 87-53 | Callithrix jacchus | 654.6 | [PNG](all_maps/fig20_source.png) | [PNG](all_maps/fig20_traced.png) |
| 21 | 87-51 | Callithrix jacchus | 588.2 | [PNG](all_maps/fig21_source.png) | [PNG](all_maps/fig21_traced.png) |
| 22 | 88-5 | Galago senegalensis | 511.4 | [PNG](all_maps/fig22_source.png) | [PNG](all_maps/fig22_traced.png) |
| 23 | 88-10 | Galago senegalensis | 792.9 | [PNG](all_maps/fig23_source.png) | [PNG](all_maps/fig23_traced.png) |
| 24 | 88-11 | Galago senegalensis | 612.2 | [PNG](all_maps/fig24_source.png) | [PNG](all_maps/fig24_traced.png) |

## Recovered OneDrive copy

See [RECOVERY_README.md](RECOVERY_README.md) for storage location, recovery verification and quick access to the files.
