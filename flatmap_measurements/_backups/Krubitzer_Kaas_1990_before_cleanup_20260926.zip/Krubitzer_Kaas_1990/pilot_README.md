# Krubitzer & Kaas (1990): flatmap measurement pilot

**Status: one flatmap measured provisionally; anatomical review needed before research use.**

The source is *Cortical connections of MT in four species of primates: Areal, modular, and retinotopic patterns*, Visual Neuroscience 5:165–204, doi:10.1017/S0952523800000213. The original PDF and existing source datasets were not edited.

## What was measured

Figure 20, printed p.190 / PDF p.26, marmoset **87-53**, *Callithrix jacchus* as reported by the paper. Hemisphere laterality has not been assigned.

The pilot traces the entire drawn tissue outline and 15 named fields: **17, 18, DM, DI, DL, MT, MST, FST, 3b, 3a, SII, PV, AI, FEF, FV**. FEF and FV include short approximate closures where lines are interrupted. PP, IT, M and PM are retained as unmeasured rows because no complete boundary defines their entire field in this figure. “Lateral sulcus” is a landmark, not a cortical field to add to the table.

The total outlined hemisphere is approximately **655 mm²**; V1 approximately **117 mm²** (17.94%), V2 **64 mm²** (9.78%) and MT **13.7 mm²** (2.10%). Values are estimates from the printed reconstruction, not newly measured histological specimens.

## Reviewable outputs

- `fig20_review.html`: self-contained source image, selectable ROI overlays, measurements, boundary notes and comparison with Table 1. The source PNG is embedded, so opening the HTML does not send it to a server. Download links require the accompanying files. Browser interaction QA was unavailable because the built-in browser blocks local-file URLs; static PNG and measurement checks were completed.
- `fig20_traced.png`: visually checked colored ROI overlay and turquoise total-tissue outline.
- `fig20_native.png`: unaltered Figure 20 crop rendered from the source.
- `fig20_measurements.csv`: all results, empty values for unmeasurable labels, provenance and sensitivity scenarios.
- `fig20_rois.json`: editable ROI vertices, calibration endpoints, crop and source information.
- `fig20_whole_mask.png`: actual total-tissue mask used as denominator; white pixels are included.
- `fig20_table1_comparison.csv`: independent range comparison, using the printed marmoset table.
- `measurement_audit.json`: source SHA-256, calibration and technical checks.
- `flatmap_inventory.csv`: all 13 main case flatmaps, with only Figure 20 marked measured.
- `measure_fig20.py`: complete reproducible measurement/export code.

## Measurement definition and reproducibility

The PDF was rendered with pypdfium2 at 2.5 pixels per PDF point (180 dpi). The crop is `(290, 160, 1250, 1070)` in that rendered page. Its origin is the upper-left corner; coordinates increase rightward and downward. There is no image stretching.

The 2 mm line has approximate endpoints `(702.5, 859.5)` and `(760.5, 860.5)` in the crop, a distance of **58.0086 pixels**. Thus:

`area_mm2 = area_px2 * (2 / 58.0086200491)^2`

The total-tissue silhouette is extracted by thresholding the scan, flood-filling exterior space, and retaining the enclosed component inside the drawn cortex. An erosion with a circular radius of 2 pixels approximates the centre of the thick outer stroke. That mask contains **550,684 pixels**. This procedure excludes exterior scale marks, labels, and page whitespace. It includes both dark and light tissue inside the outline: black tracer marks are not subtracted as holes.

Named fields are manually digitized polygons following the anatomical boundaries visible in the figure. Fractional pixel coverage is computed at 4× sampling resolution and clipped to the tissue mask. V1 uses the extracted outer-tissue contour for its external border; its polygon deliberately extends outside the figure before clipping. ROI vertices remain independent of the displayed image size. No external atlas or target percentage was used to move the boundaries.

The script checks that the silhouette is a plausible component, most polygon vertices remain within cortex, and eroded ROI interiors do not overlap. Small overlaps on shared raster edges (716 pixels across all field interfaces) are recorded explicitly; the separate ROI areas should not be added as though they form a complete mutually exclusive parcellation. The total comes from its own tissue mask.

Reproduce from this directory, using a Python environment with Pillow, numpy and pypdfium2:

```sh
python3 measure_fig20.py
```

If the original PDF moves, update `source_pdf` in `fig20_rois.json`. The original hash is saved in `measurement_audit.json`.

## Interpretation and uncertainty

1. **Denominator:** the total drawn neocortical tissue extent for one reconstructed hemisphere. This is not both hemispheres, an in-vivo pial mesh or necessarily the raw area of one histological section. The Methods (printed p.167 / PDF p.3) describe aligned drawings across section depths, including total neocortex and architectonic boundaries.
2. **Completeness:** the authors describe retaining all or nearly all neocortex, sometimes in two pieces. The pilot inherits the completeness of Figure 20; missing tissue cannot be recovered from its outline. In further cases, sum all preserved pieces and exclude the gaps introduced by flattening cuts.
3. **Boundary uncertainty:** tracer marks and drawing thickness obscure several borders. MT and the central V1/V2 boundary deserve review. Dashed lines are approximate architectonic boundaries or sulcal landmarks according to their line style; these must not be treated interchangeably. FEF and FV estimates use short interpolations across visible gaps.
4. **Calibration:** the printed line is short. The sensitivity columns vary its measured length by ±2 pixels and field boundaries by a radius of ±2 pixels. The outer-outline scenario additionally varies the threshold from 100–200 and stroke inset from 1–3 pixels. The total is approximately **608–706 mm²** under these scenarios. These are illustrative sensitivity bounds, **not statistical confidence intervals**. The assumptions can be changed in the JSON/script.
5. **Physical area:** no correction is applied for fixation, section processing, flattening or tissue shrinkage. Absolute values are in the figure's calibration. Proportions cancel a shared isotropic scale factor but do not resolve local distortion, missing tissue or boundary error.
6. **Validation:** Table 1 (printed p.175 / PDF p.11) gives eight visual-field percentages for six marmoset cases. Seven pilot proportions lie inside their species ranges. V2 is **9.78%**, slightly above the printed **7.5–9.6%** range, so it remains explicitly flagged. The numerical Table 1 cases are not securely linked to specimen 87-53; no specimen identity or exact validation match was inferred from similar measurements.

## Flatmap inventory and next scope

The most suitable individual-case figures are **12–24** (PDF pp.18–30). These comprise five squirrel-monkey drawings, three owl-monkey drawings, two marmoset drawings and three galago drawings. Only Figure 20 has been digitized in this pilot. The other figures require their own calibration and anatomical tracing; the marmoset scale must not be reused across figures.

| Figure | PDF page | Printed page | Common name | Figure specimen ID | Status |
|---|---:|---:|---|---|---|
| 12 | 18 | 182 | Squirrel monkey | 87-35 | Identified; unmeasured |
| 13 | 19 | 183 | Squirrel monkey | 87-16 | Identified; unmeasured |
| 14 | 20 | 184 | Squirrel monkey | 86-23 | Identified; unmeasured |
| 15 | 21 | 185 | Squirrel monkey | 87-15 | Identified; unmeasured |
| 16 | 22 | 186 | Squirrel monkey | 87-25 | Identified; unmeasured |
| 17 | 23 | 187 | Owl monkey | 88-7 | Identified; unmeasured |
| 18 | 24 | 188 | Owl monkey | 87-54 | Identified; unmeasured |
| 19 | 25 | 189 | Owl monkey | 88-16 | Identified; unmeasured |
| 20 | 26 | 190 | Marmoset | 87-53 | Provisional pilot complete |
| 21 | 27 | 191 | Marmoset | 87-51 | Identified; unmeasured |
| 22 | 28 | 192 | Galago | 88-5 | Identified; unmeasured |
| 23 | 29 | 193 | Galago | 88-10 | Identified; unmeasured |
| 24 | 30 | 194 | Galago | 88-11 | Identified; unmeasured |

Figure 1 is a flattening illustration. Figures 2–4 and 6–11 include partial photomicrographs or detailed reconstructions that can support border interpretation but generally lack a whole-neocortex denominator. Figures 25–26 show contralateral connection details; they cannot be assumed to represent additional independent animals. Figure 27 summarizes four species, and Figure 28 compares a macaque map modified from earlier literature. These must be tracked separately from individual specimen measurements to avoid duplicate observations.

No measurements have been inserted into `surfaceareas_long.csv`, `surfaceareas_wide.csv` or the source paper's existing tables.
