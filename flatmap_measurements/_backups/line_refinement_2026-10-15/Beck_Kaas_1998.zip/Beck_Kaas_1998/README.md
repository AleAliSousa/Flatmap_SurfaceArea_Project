# Beck & Kaas (1998): surface-area assessment

All 14 numbered figures assessed; **5 field or mapped-portion measurements**. Eight cortical insets assessed; five supported DM envelopes or visible fragments. Other cortical fields are NA where borders are incomplete or obscured.

- [Source/tracing review and all-figure assessment](review/gallery.html)
- [Measurements](data/measurements.csv)
- [Complete-field absolute-area summaries](data/field_area_summary.csv)
- [Figure inventory, repeat links and exclusion reasons](documentation/figure_inventory.csv)
- [Methods and limitations](documentation/methods.md)
- [Validation](documentation/validation.json)

Editable ImageJ exports are saved for measured views: open `figures/<map_id>/source.tif`, then **Image > Overlay > To ROI Manager**, or load `RoiSet.zip` (one route only). `Masks.tif.zip` holds named binary masks. Preserve user-edited files separately and reconcile edits into canonical `rois.json` before rebuilding. Views without a defensible ROI retain their source/calibration and explicit NA rows.

From this folder, using Python with numpy, Pillow and pypdfium2, and Java17+/ImageJ:

```sh
python scripts/rebuild_all.py
python scripts/measure_flatmaps.py --verify
```

`rebuild_all.py` regenerates measurements, native exports, overlap audits, summaries, review pages and final hashes in order; it accepts `--java` and `--ij-jar` for explicit runtime locations. No whole-neocortex denominator is established, so whole-neocortex percentages are unavailable. Absolute summaries use only complete field envelopes in main case views, excluding partial islands/fragments and repeats. All new digitizations are provisional pending anatomical review.
