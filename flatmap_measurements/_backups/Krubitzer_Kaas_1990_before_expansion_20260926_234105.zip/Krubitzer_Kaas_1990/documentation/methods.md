# Methods and limitations

## Scope

Krubitzer LA & Kaas JH (1990), *Cortical connections of MT in four species of primates: Areal, modular, and retinotopic patterns*, Visual Neuroscience 5:165–204. DOI: 10.1017/S0952523800000213.

Figures 12–24 are 13 individual-case whole-cortex reconstructions: squirrel monkey (12–16), owl monkey (17–19), marmoset (20–21), and galago (22–24). Species names follow the paper. Left/right laterality is unassigned; each map is one hemisphere, without doubling. Histological images, schematic summaries and contralateral detail panels are not counted as extra whole-hemisphere cases; see paper_figure_inventory.csv.

## Source, calibration and masks

The local source PDF in source/paper.pdf is checked against its recorded SHA-256 before rebuilding. Crops were rendered at 2.5 pixels per PDF point, then uniformly resized as recorded in source/manifest.json. Figure 20 retains its original 960 × 910 geometry; the others have width 1,100 pixels. No figure is rescaled during this cleanup.

Each figure uses its own printed scale stroke. Pixel area is converted using:

`area_mm2 = area_px2 × (scale_length_mm / scale_length_px)^2`

Saved endpoints reflect manually located, thresholded stroke extents; red crosses in tracing.png mark those endpoints. The whole-tissue mask uses outside flood filling, saved component seeds, documented contour repairs, a circular inset and saved exclusions for attached annotation artifacts. Labels, tracer dots and injection sites remain inside anatomical regions. Gaps outside flattened pieces are excluded. Figures 12 and 14 include saved short outer-contour repairs. All segmentation parameters are in the same per-figure rois.json as the field polygons.

Fields were manually traced against visible anatomical borders. Small interpretable gaps were interpolated and documented. Shared borders were aligned; proper polygon self-intersections and material interior overlaps were checked. Field areas use 3× fractional pixel coverage, or the saved 4× setting for Figure 20, and are clipped to the whole-tissue mask. These are per-figure parameters of one measurement function. The outline is measured independently: labelled fields do not constitute a complete parcellation and must not be summed to obtain the total.

## Missing information and uncertainty

Figure 19 shows “2 mm” without a recoverable scale line, including at 432 dpi (fig19_scale_detail.png). Its absolute areas remain blank; pixels and percentages are retained. The scale is not borrowed: Figures 17 and 18 have 2 mm lines of approximately 28.012 and 31.049 pixels in equally resized crops. Applied to Figure 19, they would imply approximately 1,831 and 1,490 mm², respectively. Those illustrative assumptions are not entered as measurements. See scale_comparison.csv and scale_comparison.png.

Forty-eight labels lack complete individual boundaries and are recorded as unavailable, never zero. PP and IT often denote open broad territories. Figure 18's dorsal V2 terminus is approximate. In Figure 22, the compartment labelled M includes UZ's recess; UZ has no separate closed perimeter and is not counted again. PV/IG, MI and C retain the paper's printed labels. Each row retains its detailed boundary note.

CSV sensitivity columns vary field boundaries by ±2 pixels and scale length by ±2 pixels; whole-outline boundaries vary by ±1 pixel. These are sensitivity scenarios, not confidence intervals. They do not capture every uncertainty from anatomy, dashed borders, flattening, missing tissue or processing. No shrinkage correction is applied. These are areas of published reconstructed cortical sheets, not in-vivo pial surfaces or literal single tissue sections.

## Comparison with Table 1

The printed species ranges on p.175 were used for 101 screening comparisons; 25 estimates fall outside those ranges. These flags remain visible in table1_range_check.csv. Numbered Table 1 cases have not been securely matched to figure specimen IDs, so these are not specimen-matched validation. Traces were not changed to force agreement.

## ImageJ representation

Native ImageJ ROI ZIPs and calibrated TIFFs are generated and read back by ImageJ's own library. Each exported selection matches its binary mask exactly, including disconnected components and clipped outer borders. Binary field selections use at least 50% pixel coverage; consequently their areas differ slightly from fractional CSV areas. The largest difference is approximately 0.692% (Figure 12, DM); whole-cortex counts are exact. imagej_measurements.tsv records both baselines and their differences. TIFF calibration tags add negligible numeric rounding.

Masks.tif.zip contains one named mask per slice, with 255 included and 0 excluded. The first slice is the denominator. Native ImageJ edits are saved in the user's revised ROI ZIP and Results table; they do not automatically update the baseline JSON or CSV. Rebuilding from JSON regenerates the baseline, so keep user edits under separate names.

## Verification and recovery provenance

validation.json records scientific checks, counts, scale status, overlap audits and native ImageJ read-back validation. checksums.json verifies the current package files. provenance.json preserves recovery evidence and the cleanup equivalence check. The PDF and selected image comparisons were visually inspected; gallery script syntax was checked. Browser interaction was not tested because the app's browser blocked local-file URLs.

The previous working folder disappeared. Its coordinates and source code were recovered from this chat's saved edit history, then outputs were regenerated from the unchanged paper. Before this reorganization, the complete measurement CSV matched the original SHA-256 exactly: c9b8bb30ab662a3507cfb5277562605adbc3af2af58bb658e4cdb32bfe7a1511. Cleanup changes file paths and organization; all scientific values and tracing geometry are checked against that recovered dataset. Figure 20 is fully included in the common workflow. No project-wide surface-area tables were changed.

Official ImageJ references: [ROI Manager](https://imagej.net/ij/docs/menus/analyze.html#manager), [selection tools](https://imagej.net/ij/docs/guide/146-19.html), [creating selections from masks](https://imagej.net/ij/docs/menus/edit.html).
