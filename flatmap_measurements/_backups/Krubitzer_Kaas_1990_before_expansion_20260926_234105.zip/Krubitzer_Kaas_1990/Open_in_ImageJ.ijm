// Plugins > Macros > Run; select this file, then choose fig12 ... fig24.
// Existing ROI Manager work is preserved: save/clear it yourself before loading.
requires("1.54a");
dir = getDirectory("Choose an figures/figNN folder, e.g. fig20");
if (!File.exists(dir + "source.tif") || !File.exists(dir + "RoiSet.zip"))
    exit("Choose a fig12 ... fig24 folder containing source.tif and RoiSet.zip.");
if (roiManager("count") > 0)
    exit("ROI Manager already contains selections. Save them, clear the list, then run this loader again.");
open(dir + "source.tif");
// Remove only the displayed duplicate overlay; source.tif on disk is unchanged.
run("Remove Overlay");
RoiManager.restoreCentered(false);
roiManager("open", dir + "RoiSet.zip");
roiManager("show all without labels");
getPixelSize(unit, pw, ph);
showStatus("Loaded " + roiManager("count") + " editable selections; " + pw + " " + unit + "/pixel");
