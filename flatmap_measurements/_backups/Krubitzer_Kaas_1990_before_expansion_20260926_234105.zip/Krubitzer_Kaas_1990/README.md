# Krubitzer & Kaas (1990): cortical flatmap measurements

13 individual-case maps (Figures 12–24), 186 labelled fields and 13 whole-cortex outlines. Figure 20 is included exactly like every other case. These are provisional manual digitizations requiring anatomical review.

## Open the results

- [All measurements](data/measurements.csv)
- [One-row-per-case summary](data/hemisphere_summary.csv)
- [Original images beside their tracings — PDF](review/comparison.pdf)
- [Interactive comparison gallery](review/gallery.html)
- [Methods, uncertainty and validation](documentation/methods.md)

## Find a figure or edit it in ImageJ/Fiji

Each folder under **figures/** contains the same five files:

| File | Purpose |
|---|---|
| `source.tif` | Original image pixels with calibration and an editable overlay. |
| `tracing.png` | Colored tracing for visual comparison. |
| `rois.json` | The single saved definition of that figure's coordinates, boundary notes and calibration. |
| `RoiSet.zip` | Native ImageJ selections, including the whole-cortex outline. |
| `Masks.tif.zip` | Binary mask stack: slice 1 is whole cortex, followed by named field masks. |

For example, the former Figure 20 test is now simply **figures/fig20/**.

In ImageJ/Fiji, use **Plugins > Macros > Run…**, select `Open_in_ImageJ.ijm` from this folder and choose a `figures/figNN` folder. It opens the image and named selections. Save and clear existing ROI Manager work first if needed.

Alternatively open `source.tif` and choose **Image > Overlay > To ROI Manager**. This overlay contains the same selections as `RoiSet.zip`; load only one to avoid duplicates. Select a region, edit with the Brush Selection Tool (Shift adds; Option/Alt subtracts), and click **Update**. Measure with Area enabled and Limit to Threshold disabled. Deselect all entries, then use ROI Manager **More > Save…** to save the complete edited set under a new ZIP filename. Save Results separately. ROI Manager edits do not automatically rewrite the JSON or the baseline CSV.

To start again from a mask, open `Masks.tif.zip` in ImageJ (or unzip it and open the TIFF), choose its named slice, threshold at 255–255 and use **Edit > Selection > Create Selection**. Add it to ROI Manager, activate the matching source image and refine it. The pixel dimensions must stay unchanged.

## Folder layout

- **data/** — the two measurement tables; there are no duplicated per-figure CSVs.
- **figures/** — one complete folder per figure, including editable ImageJ files.
- **review/** — comparison PDF and gallery.
- **source/** — the article and its extraction/calibration provenance.
- **documentation/** — methods, validation, comparison tables and recovery history.
- **scripts/** — one Python workflow and its native ImageJ file-format helper.

No commit is needed to use these local files. They are stored in the OneDrive project folder requested by the user; OneDrive manages cloud synchronization.

## Rebuild only if needed

There is one command for all figures, including Figure 20:

```sh
python3 scripts/rebuild.py --rebuild
```

This reads the local source PDF and each figure's `rois.json`, then regenerates measurements, image comparisons and ImageJ exports. It never recreates the JSON from a second coordinate script. **Rebuilding replaces baseline generated files**; save your ImageJ edits with a different filename first. Editing a JSON and rebuilding recalculates that figure's geometry through the same workflow.

Requirements: Python with numpy, Pillow, pypdfium2 and reportlab; Java 17; and ImageJ/Fiji. The exporter finds the installed Fiji JAR on this Mac. Other installations can pass `--java /path/to/java --ij-jar /path/to/ij.jar`.

Check the saved files without changing them:

```sh
python3 scripts/rebuild.py --verify
```

Create a portable archive only when needed, outside this folder:

```sh
python3 scripts/rebuild.py --zip ../Krubitzer_Kaas_1990.zip
```

This avoids keeping a second full copy of the dataset inside itself. A pre-cleanup recovery archive is stored separately in the parent `_backups/` folder.
