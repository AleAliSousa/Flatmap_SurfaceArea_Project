"""Rebuild or verify every flatmap through one workflow (Figures 12–24).

Canonical inputs: source/paper.pdf, source/manifest.json, figures/figNN/rois.json.
Figure 20 uses the same code as every other figure. Per-figure raster settings
remain in its JSON to preserve all original scientific measurements.
"""
from pathlib import Path
import argparse,base64,csv,hashlib,html,io,json,math,shutil,subprocess,sys,tempfile,zipfile
import numpy as np
import pypdfium2 as pdfium
from PIL import Image,ImageDraw,ImageFilter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A3,landscape
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'data'; FIGURES=ROOT/'figures'; REVIEW=ROOT/'review'; DOCS=ROOT/'documentation'
TOTALS={}
def folder(f): return FIGURES/f'fig{f:02d}'
def definition(f): return json.loads((folder(f)/'rois.json').read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def total_mask(f):
    if f in TOTALS: return TOTALS[f]
    with zipfile.ZipFile(folder(f)/'Masks.tif.zip') as z:
        with Image.open(io.BytesIO(z.read(z.namelist()[0]))) as im:
            im.seek(0);return np.array(im)>0



PALETTE={'17':'#0072b2','18':'#56b4e9','DM':'#e69f00','DI':'#cc79a7','DL':'#009e73','MT':'#d55e00','MST':'#8a5ab5','FST':'#d6a000','3b':'#208b87','3a':'#8e6f3e','1':'#576fa6','2':'#bd6259','SII':'#4871b2','PV/IG':'#ad5865','PV':'#ad5865','AI':'#55853b','FEF':'#956497','FV':'#3c8aa2','Motor & Premotor':'#808040','C':'#9a613c'}

RANGES={
 'Saimiri sciureus':{'17':[13.7,19.9],'18':[6.5,9.4],'DL':[3.4,5.7],'DM':[1.2,1.8],'DI':[.9,1.4],'FST':[2.4,3.2],'MT':[1.1,1.6],'MST':[1.1,1.8]},
 'Aotus trivirgatus':{'17':[6.7,18.4],'18':[5.,9.2],'DL':[2.2,4.2],'DM':[1.5,2.4],'DI':[1.3,1.8],'FST':[1.2,2.1],'MT':[1.3,2.1],'MST':[1.1,1.8]},
 'Callithrix jacchus':{'17':[15.7,22.3],'18':[7.5,9.6],'DL':[3.1,4.4],'DM':[1.1,1.8],'DI':[1.7,2.8],'FST':[1.7,2.7],'MT':[1.5,2.3],'MST':[1.1,1.7]},
 'Galago senegalensis':{'17':[13.5,19.6],'18':[4.4,8.0],'DL':[2.,2.9],'DM':[.6,1.2],'DI':[.7,1.4],'FST':[1.8,2.7],'MT':[1.9,2.5],'MST':[1.4,2.2]}}

def morph(mask,r,erode):
    h,w=mask.shape;p=np.pad(mask,r,constant_values=False);out=np.ones_like(mask) if erode else np.zeros_like(mask)
    for dy in range(-r,r+1):
        for dx in range(-r,r+1):
            if dx*dx+dy*dy<=r*r:
                q=p[r+dy:r+dy+h,r+dx:r+dx+w]
                if erode:out &= q
                else:out |= q
    return out

def whole_mask(im,d):
    ink=Image.fromarray(np.uint8(np.array(im.convert('L'))<d['threshold'])*255).copy()
    draw=ImageDraw.Draw(ink)
    for line in d.get('whole_repairs',[]):draw.line([tuple(p) for p in line],fill=255,width=2)
    if d['barrier_dilation_px']:ink=ink.filter(ImageFilter.MaxFilter(2*d['barrier_dilation_px']+1))
    white=Image.fromarray(255-np.array(ink)).copy();ImageDraw.floodfill(white,(0,0),127)
    enclosed=Image.fromarray(np.uint8(np.array(white)!=127)*255).copy()
    selected=np.zeros_like(np.array(enclosed),dtype=bool)
    for seed in d['whole_seeds']:
        part=enclosed.copy();ImageDraw.floodfill(part,tuple(seed),128);selected |= np.array(part)==128
    selected=morph(selected,d['edge_inset_px'],True)
    # Remove small arrow/letter components disconnected by the stroke inset.
    pruned=np.zeros_like(selected)
    for seed in d['whole_seeds']:
        component=Image.fromarray(np.uint8(selected)*255).copy()
        if not selected[seed[1],seed[0]]:raise ValueError(f'Whole-tissue seed is outside mask: {seed}')
        ImageDraw.floodfill(component,tuple(seed),128);pruned |= np.array(component)==128
    for polygon in d.get('whole_exclusions',[]):pruned &= poly_mask([polygon],pruned.shape)<.5
    return pruned

def poly_mask(polys,shape,ss=3):
    h,w=shape;im=Image.new('L',(w*ss,h*ss));draw=ImageDraw.Draw(im)
    for poly in polys:draw.polygon([(round((x+.5)*ss),round((y+.5)*ss)) for x,y in poly],fill=255)
    return np.array(im,dtype=np.float32).reshape(h,ss,w,ss).mean(axis=(1,3))/255

def measure(d):
    f=d['figure'];im=Image.open(folder(f)/'source.tif').convert('RGB');total=whole_mask(im,d)
    if d.get('whole_manual_polygon'):
        total=poly_mask([d['whole_manual_polygon']],total.shape)>=.5
    calibrated=bool(d.get('scale_endpoints_px'))
    n=int(total.sum());bar=math.dist(*d['scale_endpoints_px']) if calibrated else float('nan');factor=(d['scale_length_mm']/bar)**2
    assert n>20000,f'Figure {f}: open contour / incomplete component ({n} px)'
    TOTALS[f]=total
    base=dict(figure=f,pdf_page=d['pdf_page'],printed_page=d['printed_page'],specimen=d['specimen'],species=d['species_as_reported'],hemisphere='not assigned',scale_length_mm=d['scale_length_mm'],scale_length_px=bar,source_roi_file=f'../figures/fig{f:02d}/rois.json')
    lo=(d['scale_length_mm']/(bar+2))**2;hi=(d['scale_length_mm']/(bar-2))**2
    rows=[dict(base,label='Neocortex outline',area_px2=n,area_mm2=n*factor,percent_of_drawn_neocortex=100.,sensitivity_low_mm2=float(morph(total,1,True).sum())*lo,sensitivity_high_mm2=float(morph(total,1,False).sum())*hi,status='provisional image-derived estimate',boundary_note='Total drawn tissue, repaired at documented small scan gaps if needed; no shrinkage correction.')]
    rgba=im.convert('RGBA');masks=[];audit=[]
    for r in d['rois']:
        frac=poly_mask(r['polygons'],total.shape,d.get('supersample',3));unclipped=float(frac.sum());frac*=total;px=float(frac.sum());mask=frac>=.5;masks.append(mask)
        outside=unclipped-px
        if outside/max(unclipped,1)>.03 and not r.get('clip_to_tissue'):audit.append(f"{r['label']}: {outside/unclipped:.1%} of polygon clipped at tissue border")
        rows.append(dict(base,label=r['label'],area_px2=px,area_mm2=px*factor,percent_of_drawn_neocortex=100*px/n,sensitivity_low_mm2=float(morph(mask,2,True).sum())*lo,sensitivity_high_mm2=float((morph(mask,2,False)&total).sum())*hi,status='provisional image-derived estimate',boundary_note=r['boundary_note']))
        color=PALETTE.get(r['label'],'#9670b0');rgb=[int(color[i:i+2],16) for i in (1,3,5)];a=np.zeros((im.height,im.width,4),dtype=np.uint8);a[mask]=rgb+[55];a[mask&~morph(mask,1,True)]=rgb+[255];rgba=Image.alpha_composite(rgba,Image.fromarray(a))
    for r in d['unmeasured']:rows.append(dict(base,label=r['label'],area_px2='',area_mm2='',percent_of_drawn_neocortex='',sensitivity_low_mm2='',sensitivity_high_mm2='',status='not measurable from complete field boundary',boundary_note=r['reason']))
    edge=np.zeros((im.height,im.width,4),dtype=np.uint8);edge[total&~morph(total,1,True)]=[0,125,135,255];rgba=Image.alpha_composite(rgba,Image.fromarray(edge))
    # Calibration endpoints are shown separately from areal outlines.
    dr=ImageDraw.Draw(rgba)
    for x,y in d.get('scale_endpoints_px',[]):dr.line([(x-4,y),(x+4,y)],fill='#c00035',width=1);dr.line([(x,y-4),(x,y+4)],fill='#c00035',width=1)
    rgba.convert('RGB').save(folder(f)/'tracing.png')
    overlaps=[]
    for i in range(len(masks)):
        for j in range(i+1,len(masks)):
            inter=morph(masks[i],1,True)&morph(masks[j],1,True);count=int(inter.sum())
            if count>5:overlaps.append(dict(a=d['rois'][i]['label'],b=d['rois'][j]['label'],interior_overlap_px=count))
    if not calibrated:
        audit.append(d.get('scale_note','Missing scale line; absolute areas unavailable.'))
        for row in rows:
            for key in ['area_mm2','sensitivity_low_mm2','sensitivity_high_mm2','scale_length_px']:row[key]=''
            if row['area_px2']!='':row['status']='provisional pixels and proportions only; no visible calibration line'
    summary=dict(figure=f,specimen=d['specimen'],total_area_mm2=n*factor if calibrated else None,total_pixels=n,scale_length_px=bar if calibrated else None,measured_fields=len(d['rois']),missing_fields=len(d['unmeasured']),warnings=audit,overlaps=overlaps)
    return rows,summary

def write_csv(path,rows):
    with path.open('w',newline='') as fp:
        writer=csv.DictWriter(fp,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def n(v,places=1):return f'{float(v):.{places}f}' if v!='' else 'unavailable'

def datauri(path):
    out=io.BytesIO()
    with Image.open(path) as im: im.convert('RGB').save(out,format='PNG')
    return 'data:image/png;base64,'+base64.b64encode(out.getvalue()).decode()

def maskuri(mask):
    out=io.BytesIO();Image.fromarray(np.uint8(mask)*255).save(out,format='PNG')
    return 'data:image/png;base64,'+base64.b64encode(out.getvalue()).decode()


def build_html(maps,rows):
    content='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Krubitzer & Kaas · all case flatmaps</title>
<style>*{box-sizing:border-box}body{margin:0;color:#183243;background:#f2f5f7;font:15px/1.5 Arial,sans-serif}header,main,footer{max-width:1500px;margin:auto;padding:24px}h1{margin:4px 0;font-size:29px}h2{margin:8px 0;font-size:19px}.tag{font-size:12px;letter-spacing:.06em;color:#9a642c;background:#fff0d7;padding:5px 9px;border-radius:4px}.small{font-size:13px;color:#566d7a}.bar{display:flex;gap:16px;flex-wrap:wrap;align-items:center}.card{background:white;border:1px solid #dce5e9;border-radius:10px;padding:18px;margin:14px 0}.views{display:grid;grid-template-columns:1fr 1fr;gap:20px}.frame{position:relative}.frame img{width:100%;display:block}.frame .overlay,.frame svg{position:absolute;inset:0;width:100%;height:100%}.frame svg{pointer-events:none}select,button{font:inherit;padding:8px 12px;border:1px solid #aebfc9;border-radius:6px;background:white;color:#173e55}a{color:#12688c}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:8px;text-align:left;border-bottom:1px solid #e3e9ec}td.num,th.num{text-align:right}tr[data-label]{cursor:pointer}tr.active{background:#e6f3f8}.alert{padding:10px 14px;border-left:4px solid #d99139;background:#fff4e3}.columns{display:grid;grid-template-columns:1.4fr 1fr;gap:22px}.links{display:flex;gap:18px;flex-wrap:wrap}.nowrap{white-space:nowrap}@media(max-width:900px){.views,.columns{grid-template-columns:1fr}header,main,footer{padding:14px}}</style>
<header><span class="tag">PROVISIONAL IMAGE-DERIVED MEASUREMENTS</span><h1>13 reconstructed hemispheres, with every trace retained</h1><p>Krubitzer &amp; Kaas (1990), individual-case Figures 12–24. Compare each published image with its saved tracing. Every field estimate links to its boundary note; missing boundaries remain unmeasured.</p><div class="links"><a href="../data/measurements.csv">All measurement rows</a><a href="../data/hemisphere_summary.csv">Hemisphere summary</a><a href="comparison.pdf">Source/trace comparison PDF</a><a href="../documentation/methods.md">Methods and limitations</a></div></header>
<main><section class="card"><div class="bar"><label>Figure <select id="figure"></select></label><label>Trace opacity <input id="opacity" type="range" min="0" max="1" step="0.05" value="1"></label><button id="clear">Clear field highlight</button></div><h2 id="title"></h2><p id="meta" class="small"></p><div id="calibration"></div><div class="views"><div><h2>Published image</h2><div class="frame"><img id="source" alt="Original published flatmap"></div></div><div><h2>Saved trace</h2><div class="frame"><img id="base" alt="Original flatmap under trace"><img id="trace" class="overlay" alt="Traced cortical fields and total outline"><svg id="highlight"></svg></div></div></div><p class="small">Turquoise: whole-tissue outline. Red crosses: measured scale endpoints. Colors identify fields; unfilled cortex is included in the total. Move opacity to zero to reveal the source beneath the tracing.</p></section>
<div class="columns"><section class="card"><h2>Measurements</h2><table><thead><tr><th>Field</th><th class="num">mm²</th><th class="num">% of outline</th><th>Boundary / status</th></tr></thead><tbody id="rows"></tbody></table></section><section class="card"><h2>Selected field</h2><p id="detail">Select a table row to highlight its polygon.</p><h2>Interpretation</h2><p>All results measure the printed flattened reconstruction of one hemisphere. No correction for shrinkage or missing tissue is applied. Tracer dots and injection sites remain inside the anatomical ROI.</p><p>Some dashed and obscured borders need anatomical review. Proportions can be compared with the published species ranges in <a href="../documentation/table1_range_check.csv">Table 1 checks</a>; the original numbered table cases have not been matched to these specimen IDs. Out-of-range values are retained as review flags, not forced into agreement.</p><p>CSV sensitivity columns vary ROI boundaries by ±2 pixels and scale length by ±2 pixels (total-outline boundary ±1 pixel). These are scenarios, not confidence intervals, and do not cover every anatomical or processing uncertainty.</p><p id="files" class="links"></p><p class="small">Each figure folder contains its calibrated TIFF, tracing PNG, editable ROI JSON, ImageJ ROI ZIP and binary mask stack. Reproduction code is in scripts/. Raw pixel areas from different figure resolutions must not be compared directly.</p></section></div></main><footer class="small">Scope: all 13 individual-case whole-cortex flatmaps. Schematic, partial-section and contralateral-detail panels are inventoried separately; they are not added as independent whole-hemisphere specimens.</footer>
<script>const maps=MAPS_DATA;const byId=id=>document.getElementById(id);let current;const num=(x,n=1)=>x===''?'—':Number(x).toFixed(n);const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
maps.forEach(m=>{const o=document.createElement('option');o.value=m.figure;o.textContent=m.figure+' · '+m.metadata.specimen+' · '+m.metadata.species_as_reported;byId('figure').appendChild(o);});
function highlight(label){document.querySelectorAll('#rows tr').forEach(r=>r.classList.toggle('active',r.dataset.label===label));const row=current.rows.find(r=>r.label===label);byId('detail').textContent=row?label+' — '+row.boundary_note:'Select a table row to highlight its polygon.';const roi=current.metadata.rois.find(r=>r.label===label);const s=byId('highlight');s.setAttribute('viewBox','0 0 '+current.size.join(' '));s.innerHTML='';if(roi){s.innerHTML='<defs><mask id="tissue" maskUnits="userSpaceOnUse" x="0" y="0" width="'+current.size[0]+'" height="'+current.size[1]+'"><image width="'+current.size[0]+'" height="'+current.size[1]+'" href="'+current.mask+'"/></mask></defs><g mask="url(#tissue)">'+roi.polygons.map(p=>'<polygon points="'+p.map(v=>v.join(',')).join(' ')+'" fill="#ffcc33" fill-opacity="0.12" stroke="#b40042" stroke-width="3"/>').join('')+'</g>';}}
function render(){current=maps.find(m=>m.figure===Number(byId('figure').value));const d=current.metadata,t=current.rows[0];byId('title').textContent='Figure '+d.figure+' · '+d.species_as_reported+' · '+d.specimen;byId('meta').textContent='PDF page '+d.pdf_page+' / printed page '+d.printed_page+' · '+d.rois.length+' traced fields · hemisphere side not assigned';byId('source').src=current.source;byId('base').src=current.source;byId('trace').src=current.trace;byId('calibration').innerHTML=t.area_mm2!==''?'<p>Total drawn neocortex: <b>'+num(t.area_mm2)+' mm²</b> · '+d.scale_length_mm+' mm calibration line.</p>':'<p class="alert">The 2 mm label is present, but its scale line is absent. Absolute mm² are unavailable; pixels and cortex percentages are retained.</p>';byId('rows').innerHTML=current.rows.map(r=>'<tr data-label="'+esc(r.label)+'"><td>'+esc(r.label)+'</td><td class="num nowrap">'+num(r.area_mm2)+'</td><td class="num">'+num(r.percent_of_drawn_neocortex,2)+'</td><td>'+esc(r.boundary_note)+'</td></tr>').join('');document.querySelectorAll('#rows tr').forEach(r=>r.onclick=()=>highlight(r.dataset.label));const f=String(d.figure).padStart(2,'0');byId('files').innerHTML='<a href="../figures/fig'+f+'/source.tif">Source TIFF</a><a href="../figures/fig'+f+'/tracing.png">Trace PNG</a><a href="../figures/fig'+f+'/rois.json">ROI coordinates</a>';highlight(null);}
byId('figure').onchange=render;byId('opacity').oninput=()=>byId('trace').style.opacity=byId('opacity').value;byId('clear').onclick=()=>highlight(null);byId('figure').value='12';render();</script></html>'''
    (REVIEW/'gallery.html').write_text(content.replace('MAPS_DATA',json.dumps(maps,separators=(',',':'))))

def build_pdf(maps):
    w,h=landscape(A3);pdf=canvas.Canvas(str(REVIEW/'comparison.pdf'),pagesize=(w,h));pdf.setTitle('Krubitzer & Kaas 1990: source and traced flatmaps');pdf.setAuthor('Image-derived measurement review')
    for m in maps:
        d=m['metadata'];fig=m['figure'];total=m['rows'][0]
        pdf.setFillColorRGB(.08,.18,.24);pdf.setFont('Helvetica-Bold',19);pdf.drawString(25,h-34,f"Figure {fig} | {d['species_as_reported']} | specimen {d['specimen']}")
        pdf.setFont('Helvetica',10);pdf.drawString(25,h-52,f"Printed p.{d['printed_page']} / PDF p.{d['pdf_page']} | PROVISIONAL | One reconstructed hemisphere; side not assigned")
        if total['area_mm2']:
            title=f"Total drawn neocortex: {n(total['area_mm2'])} mm2 | Scale: {d['scale_length_mm']} mm / {float(total['scale_length_px']):.2f} px"
        else:title='No visible scale line: absolute areas unavailable; pixel areas and cortex fractions retained.'
        pdf.drawString(25,h-68,title)
        left=25;cw=430;top=h-99;maxh=h-164
        for ix,kind in enumerate(['source','traced']):
            x=left+ix*(cw+15);pdf.setFont('Helvetica-Bold',11);pdf.drawString(x,top+8,'Published source' if ix==0 else 'Saved field tracing')
            image=Image.open(folder(fig)/('source.tif' if kind=='source' else 'tracing.png'))
            bx=Image.fromarray(np.uint8(total_mask(fig))*255).getbbox()
            if bx:image=image.crop((max(0,bx[0]-12),max(0,bx[1]-12),min(image.width,bx[2]+12),min(image.height,bx[3]+12)))
            scale=min(cw/image.width,maxh/image.height);iw=image.width*scale;ih=image.height*scale
            pdf.drawImage(ImageReader(image),x+(cw-iw)/2,top-ih,width=iw,height=ih,mask='auto')
        x=925;y=top;pdf.setFont('Helvetica-Bold',10);pdf.drawString(x,y,'Field');pdf.drawRightString(w-82,y,'mm2');pdf.drawRightString(w-25,y,'% cortex');y-=19
        for row in m['rows']:
            label='Total outline' if row['label']=='Neocortex outline' else row['label'];pdf.setFont('Helvetica',9)
            pdf.drawString(x,y,label);pdf.drawRightString(w-82,y,n(row['area_mm2']) if row['area_mm2'] else '--');pdf.drawRightString(w-25,y,n(row['percent_of_drawn_neocortex'],2) if row['percent_of_drawn_neocortex'] else '--');y-=17
        pdf.setFont('Helvetica',8);notes=['Blank values are unavailable, not zero.','Colors show field ROIs; turquoise is total tissue.','Black tracer is included, not subtracted.','All coordinates and boundary notes are in CSV/JSON.','No shrinkage correction. Review anatomy before use.']
        for line in notes:pdf.drawString(x,y-12,line);y-=13
        pdf.setFont('Helvetica',9);pdf.drawString(25,34,'Compare with source TIFFs, tracing PNGs and selectable HTML gallery. Dashed, obscured and open boundaries are documented individually.')
        pdf.drawRightString(w-25,20,f'{fig-11} / 13');pdf.showPage()
    pdf.save()

def render_sources():
    manifest=json.loads((ROOT/'source/manifest.json').read_text())
    pdf=ROOT/'source/paper.pdf'
    if digest(pdf)!=manifest['source_sha256']:
        raise ValueError('Source PDF differs from the digitized original; check registration before reusing ROIs.')
    doc=pdfium.PdfDocument(str(pdf))
    for d in manifest['crops']:
        im=doc[d['pdf_page']-1].render(scale=d['pdf_render_scale']).to_pil().convert('RGB').crop(tuple(d['crop_xyxy']))
        if list(im.size)!=d['source_size']:im=im.resize(tuple(d['source_size']),Image.Resampling.LANCZOS)
        # ImageJ adds calibration and a reversible overlay during export below.
        im.save(folder(d['figure'])/'source.tif')

def export_imagej(rows,args):
    jars=sorted(Path('/Applications/Fiji.app/jars').glob('ij-[0-9]*.jar'))
    jar=Path(args.ij_jar) if args.ij_jar else (jars[0] if len(jars)==1 else None)
    if jar is None or not jar.is_file():raise FileNotFoundError('Specify --ij-jar with the installed ImageJ JAR path.')
    with tempfile.TemporaryDirectory(prefix='kk1990_masks_') as temp:
        tmp=Path(temp);jobs=[]
        for f in range(12,25):
            d=definition(f);whole=total_mask(f);ends=d['scale_endpoints_px']
            size=d['scale_length_mm']/math.dist(*ends) if ends else 1.;unit='mm' if ends else 'pixel'
            saved={r['label']:r for r in rows if int(r['figure'])==f}
            selections=[('Neocortex outline',whole)]+[(r['label'],(poly_mask(r['polygons'],whole.shape,d.get('supersample',3))*whole)>=.5) for r in d['rois']]
            for i,(label,mask) in enumerate(selections):
                p=tmp/f'fig{f}_{i:02d}.png';Image.fromarray(np.uint8(mask)*255).save(p)
                jobs.append([f,i,label,str(folder(f)/'source.tif'),str(p),size,unit,saved[label]['area_px2'],PALETTE.get(label,'#007d87' if i==0 else '#9670b0')])
        jobfile=tmp/'jobs.tsv'
        with jobfile.open('w',newline='') as fp:
            writer=csv.writer(fp,delimiter='\t');writer.writerow(['figure','index','label','source','mask','pixel_size','unit','original_pixels','color']);writer.writerows(jobs)
        subprocess.run([args.java,'-Djava.awt.headless=true','-cp',str(jar),str(ROOT/'scripts/ImageJIO.java'),str(jobfile),str(FIGURES),str(DOCS)],check=True)
    checks=list(csv.DictReader((DOCS/'imagej_measurements.tsv').open(),delimiter='\t'))
    worst=max(checks,key=lambda r:abs(float(r['pixel_difference_percent'])))
    return dict(native_ROIs=len(checks),all_mask_ROI_TIFF_roundtrips_exact=all(r['roi_roundtrip_pixels_equal']=='true' for r in checks),
        calibrated_figures=12,uncalibrated_figure=19,largest_binary_vs_fractional_difference_percent=abs(float(worst['pixel_difference_percent'])),
        largest_difference_figure=int(worst['figure']),largest_difference_label=worst['label'],runtime=(DOCS/'imagej_runtime.txt').read_text().strip(),gui_interaction_tested=False)

def build_review(rows,audits):
    maps=[];summary=[];comparisons=[];scales=[]
    crops={d['figure']:d for d in json.loads((ROOT/'source/manifest.json').read_text())['crops']}
    for f in range(12,25):
        d=definition(f);rr=[r for r in rows if int(r['figure'])==f];total=rr[0];audit=next(x for x in audits if x['figure']==f)
        summary.append(dict(figure=f,pdf_page=f+6,printed_page=f+170,specimen=d['specimen'],species=d['species_as_reported'],
            neocortex_mm2=total['area_mm2'],neocortex_pixels=total['area_px2'],measured_fields=audit['measured_fields'],unmeasured_labels=audit['missing_fields'],
            calibration='visible scale line' if d['scale_endpoints_px'] else 'line absent; proportions only',
            source_image=f'../figures/fig{f}/source.tif',traced_image=f'../figures/fig{f}/tracing.png',roi_vertices=f'../figures/fig{f}/rois.json',status='provisional, trace review required'))
        for row in rr:
            if row['label'] in RANGES[row['species']] and row['percent_of_drawn_neocortex']!='':
                low,high=RANGES[row['species']][row['label']];pct=float(row['percent_of_drawn_neocortex'])
                comparisons.append(dict(figure=f,specimen=row['specimen'],species=row['species'],field=row['label'],digitized_percent=pct,
                    printed_species_min=low,printed_species_max=high,within_species_range=low<=pct<=high,
                    comparison_type='species range only; Table 1 case identities not matched'))
        maps.append(dict(figure=f,metadata=d,rows=rr,source=datauri(folder(f)/'source.tif'),trace=datauri(folder(f)/'tracing.png'),mask=maskuri(total_mask(f)),size=list(Image.open(folder(f)/'source.tif').size)))
        c=crops[f];ends=d['scale_endpoints_px'];bar=math.dist(*ends) if ends else None;points=bar/(c['resize_scale']*c['pdf_render_scale']) if bar else None
        scales.append(dict(figure=f,specimen=d['specimen'],bar_tissue_mm=d['scale_length_mm'],bar_in_saved_image_pixels=bar,resize_scale=c['resize_scale'],bar_length_pdf_points=points,
            bar_length_printed_mm=points*25.4/72 if points else None,tissue_mm_per_pdf_point=d['scale_length_mm']/points if points else None,status='measured scale stroke' if bar else 'no visible scale stroke; not calibrated'))
    write_csv(DATA/'hemisphere_summary.csv',summary);write_csv(DOCS/'table1_range_check.csv',comparisons);write_csv(DOCS/'scale_comparison.csv',scales)
    build_html(maps,rows);build_pdf(maps)
    return dict(hemispheres=13,traced_fields=sum(len(m['metadata']['rois']) for m in maps),whole_outlines=13,
        absolute_area_rows=sum(r['area_mm2']!='' for r in rows),pixel_area_rows=sum(r['area_px2']!='' for r in rows),
        unmeasured_rows=sum(r['area_px2']=='' for r in rows),range_checks=len(comparisons),outside_species_range=sum(not r['within_species_range'] for r in comparisons))


def verify():
    rows=list(csv.DictReader((DATA/'measurements.csv').open()))
    assert {int(r['figure']) for r in rows}==set(range(12,25))
    audits=json.loads((DOCS/'validation.json').read_text())['measurement_audit']
    assert len(audits)==13 and all(not a['overlaps'] for a in audits)
    for f in range(12,25):
        rr=[r for r in rows if int(r['figure'])==f];total=next(r for r in rr if r['label']=='Neocortex outline')
        assert len({r['label'] for r in rr})==len(rr)
        dims=[Image.open(folder(f)/name).size for name in ['source.tif','tracing.png']]+[tuple(reversed(total_mask(f).shape))]
        assert len(set(dims))==1
        d=definition(f)
        assert d['specimen']==total['specimen']
        for r in rr:
            if not r['area_px2']:
                assert not r['area_mm2'] and not r['percent_of_drawn_neocortex']
                continue
            px=float(r['area_px2']);den=float(total['area_px2']);pct=float(r['percent_of_drawn_neocortex'])
            assert 0<px<=den and math.isclose(pct,100*px/den,rel_tol=1e-9)
            if d['scale_endpoints_px']:
                factor=(d['scale_length_mm']/math.dist(*d['scale_endpoints_px']))**2
                area=float(r['area_mm2']);assert math.isclose(area,px*factor,rel_tol=1e-9)
                assert float(r['sensitivity_low_mm2'])<=area<=float(r['sensitivity_high_mm2'])
            else:assert f==19 and r['area_mm2']==''
        def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
        for roi in d['rois']:
            for p in roi['polygons']:
                for i in range(len(p)):
                    a,b=p[i],p[(i+1)%len(p)]
                    for j in range(i+2,len(p)):
                        if i==0 and j==len(p)-1:continue
                        c,e=p[j],p[(j+1)%len(p)]
                        assert not(cross(a,b,c)*cross(a,b,e)<0 and cross(c,e,a)*cross(c,e,b)<0),(f,roi['label'],'self-intersection')
    
        assert int(total_mask(f).sum())==int(float(total['area_px2']))
        assert (DATA/total['source_roi_file']).resolve()==(folder(f)/'rois.json').resolve()
        with zipfile.ZipFile(folder(f)/'RoiSet.zip') as z:
            assert z.testzip() is None and len(z.namelist())==len(d['rois'])+1
            assert all(z.read(name)[:4]==b'Iout' for name in z.namelist())
    print('Verified: 13 figures, 199 selections, calibration, area fractions, image registration and polygon geometry.')


def save_checksums():
    hashes={str(p.relative_to(ROOT)):digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ['.DS_Store','checksums.json']}
    (DOCS/'checksums.json').write_text(json.dumps(hashes,indent=2)+'\n')

def verify_checksums():
    for name,expected in json.loads((DOCS/'checksums.json').read_text()).items():
        if not (ROOT/name).is_file() or digest(ROOT/name)!=expected:
            raise ValueError('File changed since the last rebuild: '+name)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--rebuild',action='store_true',help='Regenerate baseline images, measurements, review and ImageJ exports from saved JSON traces.')
    action.add_argument('--verify',action='store_true',help='Check geometry, measurements and saved file hashes without changing files.')
    action.add_argument('--zip',type=Path,metavar='PATH',help='Create a portable ZIP outside this folder without rebuilding.')
    parser.add_argument('--java',default='/Library/Java/JavaVirtualMachines/zulu-17.jdk/Contents/Home/bin/java')
    parser.add_argument('--ij-jar',default=None)
    args=parser.parse_args()
    if args.zip:
        target=args.zip.resolve()
        if target.is_relative_to(ROOT) or target.exists():raise ValueError('Choose a new ZIP filename outside this dataset folder.')
        verify_checksums()
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for name in json.loads((DOCS/'checksums.json').read_text()):z.write(ROOT/name,str(Path(ROOT.name)/name))
            z.write(DOCS/'checksums.json',str(Path(ROOT.name)/'documentation/checksums.json'))
        print('Saved',target);return
    if args.verify:
        verify_checksums();verify();return
    render_sources();rows=[];audits=[]
    for f in range(12,25):
        rr,aa=measure(definition(f));rows.extend(rr);audits.append(aa)
    write_csv(DATA/'measurements.csv',rows)
    imagej=export_imagej(rows,args);summary=build_review(rows,audits)
    (DOCS/'validation.json').write_text(json.dumps(dict(summary=summary,measurement_audit=audits,imagej=imagej),indent=2)+'\n')
    verify();save_checksums();print(json.dumps(summary,indent=2))

if __name__=='__main__':main()

