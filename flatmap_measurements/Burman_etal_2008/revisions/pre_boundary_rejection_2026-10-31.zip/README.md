# Burman_etal_2008

Marmoset: dorsal M1 components, M1-face component and core visual/sensory/auditory fields from Fig9A. Pixel areas only: Fig6 caption prints 1 μm, inconsistent with a whole-brain image; Fig9 bar length is not specified. No silent correction to 1 mm. Additional atlas labels are listed as not yet digitized, not falsely classified as impossible.

## Results

- [Source-versus-tracing gallery](review/gallery.html)
- [Measurements](data/measurements.csv)
- [Figure inventory](documentation/figure_inventory.csv)
- [Validation](documentation/validation.json)

Canonical editable geometry is in `figures/<map_id>/rois.json`. Every traced view has a calibrated or pixel-unit `source.tif`, editable ImageJ `RoiSet.zip`, masks and `tracing.png`. Source-only views intentionally contain no ROI.

All measurements remain provisional manual digitizations. Source review and native ImageJ read-back do not certify anatomical accuracy. No field sum was used to invent a whole-neocortex denominator. A view is not an animal.

Rebuild from this folder with `python scripts/measure_flatmaps.py --rebuild`, then `python scripts/measure_flatmaps.py --verify`. Batch tables/report can be regenerated with the batch report script.
